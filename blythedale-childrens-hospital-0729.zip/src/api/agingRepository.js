import axios from "axios";

const getAgingAccountSummary = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }

        let API_URL = "";
        if (import.meta.env.VITE_USE_JSON_DB === 'false') {
            API_URL = `${import.meta.env.VITE_API_BASE_URL}/aging/${selectedUser}`;
        } else {
            API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/aging`;
        }

        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching task summary by aging:', error);
        throw error;
    }
};

const getDenialAlertData = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }
        let API_URL = "";
        if (import.meta.env.VITE_USE_JSON_DB === 'false') {
            API_URL = `${import.meta.env.VITE_API_BASE_URL}/denial/alerts/${selectedUser}`;
        } else {
            API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/denial`;
        }

        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching denial alert data:', error);
        throw error;
    }
};

export { getAgingAccountSummary, getDenialAlertData };
