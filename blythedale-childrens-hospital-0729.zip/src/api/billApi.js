import axios from "axios";

const getBillDetails = async (AccountNumber, BillNo) => {
    let API_URL = "";
    if (import.meta.env.VITE_USE_JSON_DB === 'false') {
      API_URL = `${import.meta.env.VITE_API_BASE_URL}/bill/details/${AccountNumber}/${BillNo}`;
    } else {
      API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/billDetails?account=${AccountNumber}&bill=${BillNo}`;
    }   
    try {
      const response = await axios.get(API_URL);
      return response;
    } catch (error) {
      console.error("Error fetching bill details:", error);
      throw error;
    }
  };

  const getBillBasedOnAccount = async (url) => {
    let API_URL = "";
    if (import.meta.env.VITE_USE_JSON_DB === 'false') {
      API_URL = `${import.meta.env.VITE_API_BASE_URL}/${url}`;
    } else {
      API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/task`;
    }   
    try {
      const response = await axios.get(API_URL);
      return response;
    } catch (error) {
      console.error("Error fetching bill details:", error);
      throw error;
    }
  };
  const getGeneratedData = async (AccountNumber,BillNo, EntryBy) => {
    let API_URL = "";
    if (import.meta.env.VITE_USE_JSON_DB === 'false') {
      API_URL = `${import.meta.env.VITE_API_BASE_URL}/analyze_notes?EntryBy=${EntryBy}&AccountNumber=${AccountNumber}&BillNo=${BillNo}`;
    } else {
      API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/generatedData`;
    }   
    try {
      const response = await axios.get(API_URL);
      return response;
    } catch (error) {
      console.error("Error fetching bill details:", error);
      throw error;
    }
  }

  export { getBillDetails, getBillBasedOnAccount, getGeneratedData };
