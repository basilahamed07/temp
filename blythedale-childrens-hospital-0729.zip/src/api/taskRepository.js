import axios from "axios";

const fetchActionableTaskSummary = async (param, path) => {
  console.log("asdf", path)
  try {
    const selectedUser = localStorage.getItem("selectedUser");
    if (!selectedUser) {
      alert("Error: No user selected. Please select a user.");
      return;
    }
    let API_URL = "";
    if (import.meta.env.VITE_USE_JSON_DB === 'false') {
      API_URL = `${import.meta.env.VITE_API_BASE_URL}/${path}/${selectedUser}/${param}`;
    } else {
      API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/task`;
    }

    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching task summary by aging:', error);
    throw error;
  }
};

export { fetchActionableTaskSummary };
