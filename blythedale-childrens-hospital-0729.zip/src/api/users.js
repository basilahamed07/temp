import axios from "axios";

export const getUsers = async () => {
    let API_URL = "";
    if (import.meta.env.VITE_USE_JSON_DB === 'false') {
        API_URL = `${import.meta.env.VITE_API_BASE_URL}/users/unique`;
    } else {
        API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/users`;
    }
    try {
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    }
};
