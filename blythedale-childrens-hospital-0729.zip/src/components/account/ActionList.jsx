import React from "react";
import ActionListItem from "./ActionListItem";

const ActionList = () => {
  const actionData = [
    {
      itemHeader: "Claim #H5921030 – Policy & Eligibility Check",
      itemBody: "Confirm insurance coverage and validate policy details with patient/guardian",
    },
    {
      itemHeader: "Claim #H5921030 – Claim Drafting",
      itemBody: "Extract services from EMR and prepare initial claim with all billed components",
    },
    {
      itemHeader: "Claim #H5921030 – Documentation Upload",
      itemBody: "Attach required clinical notes, referrals, and consents.",
    },
    {
      itemHeader: "Claim #H5921030 – Claim Submission",
      itemBody: "Submit claim via Clearinghouse; track for errors or rejections.",
    },
    {
      itemHeader: "Claim #H5921030 – Insurer Response Handling",
      itemBody: "Monitor for acceptance/denial and address any flags or queries.",
    },
    {
      itemHeader: "Claim #H5921030 – Payment Posting & Review",
      itemBody: "Reconcile ERA with expected payment; escalate if underpaid/denied.",
    },
    
  ];

  return (
    <div className="card h-100 shadow-sm">
      <div className="card-header text-white fw-semibold py-4 rounded bg-purple">
  Action List
</div>
      <div className="card-body small pt-1">
        {actionData.map((item, index) => (
          <ActionListItem key={index} item={item} />
        ))}
      </div>
    </div>
  );
};

export default ActionList;
