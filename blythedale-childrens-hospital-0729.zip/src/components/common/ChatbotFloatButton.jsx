import React, { useState } from 'react';
import axios from 'axios';
import styles from '../../styles/ChatbotFloatButton.module.css';
import { FaUserCircle } from 'react-icons/fa';
import { FiCopy } from 'react-icons/fi';
import { IoMdSend } from "react-icons/io";
import { flushSync } from 'react-dom';
import { marked } from 'marked';

const SAMPLE_PROMPTS = [
  'What is the total outstanding insurance claim amount?',
  'What is the average claim reimbursement rate by payer?',
  'How much was reimbursed by insurers in the last 30 days?'
];

function formatMarkdown(text) {
  try {
    if (typeof text !== 'string') return '';
    return marked.parse(text);
  } catch (err) {
    return typeof text === 'string' ? text.replace(/\n/g, '<br>') : '';
  }
}

const ChatbotFloatButton = () => {
  const [showModal, setShowModal] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);

  const getCurrentTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleSend = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    const userMessage = {
      type: 'user',
      text: prompt,
      time: getCurrentTime(),
    };
    // Add user message and a loading assistant message
    flushSync(() => {
      setChatHistory(prev => [
        ...prev,
        userMessage,
        {
          type: 'assistant',
          time: getCurrentTime(),
          text: { type: 'text', value: "I'm working on your insights... You can keep exploring or ask another prompt while I process this!", loading: true }
        }
      ]);
    });
    setPrompt('');
    try {
      const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
      const res = await axios.post(`${API_BASE_URL}/chat`, { message: prompt });
      const data = res.data;
      // If backend returns a result list, treat as result, else as text
      const newAssistantMsg = {
        type: 'assistant',
        time: getCurrentTime(),
        text: data.resultList
          ? { type: 'replay', value: data.resultList }
          : { type: 'text', value: data.reply   || 'No response' }
      };
      // Replace the last assistant message (loading) with the real result
      setChatHistory(prev => {
        const lastUserIdx = prev.map(m => m.type).lastIndexOf('user');
        const loadingIdx = lastUserIdx + 1;
        return [
          ...prev.slice(0, loadingIdx),
          newAssistantMsg,
          ...prev.slice(loadingIdx + 1)
        ];
      });
    } catch (e) {
      setChatHistory(prev => {
        const lastUserIdx = prev.map(m => m.type).lastIndexOf('user');
        const loadingIdx = lastUserIdx + 1;
        return [
          ...prev.slice(0, loadingIdx),
          {
            type: 'assistant',
            time: getCurrentTime(),
            text: { type: 'text', value: `Sorry, I couldn't process your request. Please try again.`, loading: false }
          },
          ...prev.slice(loadingIdx + 1)
        ];
      });
    }
    setLoading(false);
  };

  const handleSampleClick = (sample) => {
    setPrompt(sample);
  };

  const renderAssistantResult = (resultList) => {
    if (!Array.isArray(resultList) || resultList.length === 0) {
      return (
        <div className={styles.assistantResultBox}>
          <div className={styles.assistantLabel}><img src="/chat-avatar.svg" alt="Bot" className={styles.chatAvatarSmall} /> Billing Assistant</div>
          <div className={styles.assistantResponse}>No results found.</div>
        </div>
      );
    }
    return (
      <div className={styles.assistantResultBox}>
        <div className={styles.assistantLabel}><img src="/chat-avatar.svg" alt="Bot" className={styles.chatAvatarSmall} /> Billing Assistant</div>
        <div className={styles.assistantResponse}>
          The average claim reimbursement rates by payer are as follows:
          <ol className={styles.resultList}>
            {resultList.map((item, idx) => (
              <li key={idx}>
                {item.payer}: <span className={styles.resultAmount}>${item.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    );
  };

  return (
    <>
      <button className={styles.chatbotButton} onClick={() => setShowModal(true)}>
        <img src="/chat-icon.png" alt="Chatbot" className={styles.icon} />
        <span className={styles.label}>Chatbot</span>
      </button>

      {showModal && (
        <div className={styles.modalOverlay} tabIndex="-1" role="dialog">
          <div className={styles.modalDialog} role="document">
            <div className={styles.modalContent}>
              <div className={styles.modalHeader}>
                <div className={styles.headerLeft}>
                  <img src="/chat-avatar.svg" alt="Chatbot" className={styles.headerIcon + ' ' + styles.transparentIcon} />
                  <div className={styles.headerTextBlock}>
                    <span className={styles.aiTitle}>AI Chatbot</span>
                    <br />
                    <span className={styles.poweredBy}>Powered by GenAI</span>
                  </div>
                </div>
                <button type="button" className={styles.closeBtnOutline} aria-label="Close" onClick={() => setShowModal(false)}>
                  Close
                </button>
              </div>
              {(chatHistory.length === 0 && !loading) ? (
                <>
                  <h2 className={styles.assistantTitle}>PatientCare Billing Assistant</h2>
                  <div className={styles.assistantDesc}>
                    Quickly retrieve billing summaries and insurance details for<br />better treatment planning
                  </div>
                  <div className={styles.promptArea}>
                    <div className={styles.inputContainer}>
                      <textarea
                        className={styles.textScrollArea}
                        placeholder="Type your prompt here"
                        value={prompt}
                        maxLength={500}
                        onChange={e => setPrompt(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                      />
                      <div className={styles.controlsArea}>
                        <span className={styles.charCount}>{prompt.length}/500</span>
                        <button
                          className={styles.sendArrowButton}
                          onClick={handleSend}
                          disabled={loading || !prompt.trim()}
                          type="button"
                          aria-label="Send"
                        >
                          <IoMdSend size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className={styles.samplePromptRow}>
                    <div className={styles.samplePromptLabel}>Try Something with this</div>
                    <div className={styles.samplePromptList}>
                      {SAMPLE_PROMPTS.map((sample, idx) => (
                        <div
                          key={idx}
                          className={styles.samplePromptCard}
                          onClick={() => handleSampleClick(sample)}
                        >
                          {sample}
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Chat UI after prompt is sent */}
                  <div className={styles.chatHistoryArea}>
                    {chatHistory.map((msg, idx) =>
                      msg.type === 'user' ? (
                        <div key={idx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                          <div className={styles.userPromptBubble}>
                            <div className={styles.userPromptHeaderSmall}>
                              <FaUserCircle className={styles.userIconSmall} />
                              <span className={styles.userLabelSmall}>You</span>
                            </div>
                            <span className={styles.userPromptText}>{msg.text}</span>
                          </div>
                          <div className={styles.userPromptTimeCopyRow}>
                            <span className={styles.userPromptTimeLeft}>{msg.time}</span>
                            <button className={styles.copyButton} title="Copy" onClick={() => navigator.clipboard.writeText(msg.text)}>
                              <FiCopy />
                            </button>
                          </div>
                        </div>
                      ) : (
                        (msg.text.type === 'result' && Array.isArray(msg.text.value)) ? (
                          <div key={idx}>{renderAssistantResult(msg.text.value)}</div>
                        ) : (
                          <div key={idx} className={styles.responseArea}>
                            <div className={styles.assistantLabel}><img src="/chat-avatar.svg" alt="Bot" className={styles.chatAvatarSmall} /> Billing Assistant</div>
                            <div className={styles.assistantResponse}>
                              {msg.text.loading ? (
                                <span className={styles.loadingSpinner}>
                                  <span className={styles.spinner} />
                                  <span style={{ marginLeft: 8 }}>...</span>
                                </span>
                              ) : (
                                <span dangerouslySetInnerHTML={{ __html: formatMarkdown(msg.text.value) }} />
                              )}
                            </div>
                          </div>
                        )
                      )
                    )}
                  </div>
                  <div className={styles.promptArea}>
                    <div className={styles.inputContainer}>
                      <textarea
                        className={styles.textScrollArea}
                        placeholder="Type your prompt here"
                        value={prompt}
                        maxLength={500}
                        onChange={e => setPrompt(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                      />
                      <div className={styles.controlsArea}>
                        <span className={styles.charCount}>{prompt.length}/500</span>
                        <button
                          className={styles.sendArrowButton}
                          onClick={handleSend}
                          disabled={loading || !prompt.trim()}
                          type="button"
                          aria-label="Send"
                        >
                          <IoMdSend size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatbotFloatButton; 