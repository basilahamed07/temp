import { FaExclamationCircle } from "react-icons/fa";
import { IoClose } from "react-icons/io5";

const DialogHeader = ({ onClose, billNumber, accountNumber }) => {
    return (
        // <div className="flex items-center justify-between rounded-t-2xl from-blue-500 ">
            <div className="custom-dialog-header">
                <h4 className="text-lg font-semibold">Actions Required</h4>
                <h6 className="text-sm opacity-60">Account Number: {accountNumber} | Bill No: {billNumber}</h6>
            </div>
        // </div>
    );
};
export default DialogHeader;