import React from 'react';
import { useNavigate } from 'react-router-dom';

const NavigationLink = ({ label, state, title }) => {
  const navigate = useNavigate();

  const handleClick = (e) => {
    e.preventDefault();
    console.log("state=====", state)
    navigate('/accounts', { state });
  };

  return (
    <a
      href="#"
      onClick={handleClick}
      title={title}
      className="navigation-link"
    >
      {label}
    </a>
  );
};

export default NavigationLink;
