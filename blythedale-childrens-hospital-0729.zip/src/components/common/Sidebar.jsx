import React from "react";
import { GiHamburgerMenu } from "react-icons/gi";
import "./Sidebar.css";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="hamburger">
        <GiHamburgerMenu size={20} color="white" />
      </div>
    </div>
  );
};

export default Sidebar;
