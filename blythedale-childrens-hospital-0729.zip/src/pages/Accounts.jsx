/**
 * @file TaskList.jsx
 * @summary Actionable Task Summary component
 * @description This component displays the actionable task summary for the day
 * @author 
 * @since Jan 15, 2025
 */
import React, { useEffect, useState } from 'react'
import PrimeDataTable from '../components/common/PrimeDataTable';
import { fetchActionableTaskSummary } from '../api/taskRepository';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import TableContainer from '../components/common/TableContainer';

/**
 * @function TaskList
 * @description This component displays the actionable task summary for the day
 * @returns {JSX.Element} The TaskList component
 */
function Account({handleUserDropDown}) {
    const selectedUser = localStorage.getItem("selectedUser");
    const [actionableTasks, setActionableTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const location = useLocation();
    const code = location.state?.DenialCode ? location.state?.DenialCode : location.state?.aging ? location.state?.aging : '';
    const url = location.state?.url;
    console.log('code:', code, 'url:', url);
    /**
    * @function fetchData
    * @description This function fetches the actionable task summary for the day
    * @returns {Promise<void>} The Promise that resolves to the actionable task summary
    */
    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            console.log("url====",url )
            const data = await fetchActionableTaskSummary(code, url);
            setActionableTasks(data);
        } catch (err) {
            setError('Failed to load actionable tasks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
        handleUserDropDown(false);
    }, []);
    // Define columns for the PrimeDataTable
    const columns = [
        { field: 'AccountNumber', header: 'Account ID', sortable: false},
        { field: 'BillCount', header: 'Bill Count', sortable: false, body: (rowData) => (
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                navigate('/bills', { state: { AccountNumber: rowData.AccountNumber , DenialCode: location.state?.DenialCode,aging: location.state?.aging, accounturl:location.state?.url ,  url: `aging/details/bills/${rowData.AccountNumber}/${code}?entry_by=${selectedUser}`} });
                // navigate(`/accounts?test=asdfAccountNumber=${rowData.AccountNumber}&BillNo=${rowData.BillNo}`);
              }}
              style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer',  whiteSpace: 'normal', wordBreak: 'break-word' }}
            >
              {rowData.BillCount}
            </a>
          ) },
        { field: 'Name', header: 'Name', sortable: false },
        { field: 'AccountType', header: 'Account Type', sortable: false},
        { field: 'TotalAmount', header: 'Total Amount', sortable: false },
        { field: 'EntryBy', header: 'Biller', sortable: false }
    ];

    return (
        <div className='main'>
            <div className='content'>
                <div className="container py-4">
                    <h2 className="mb-4 fw-bold">{location.state?.DenialCode ? "Denial Alerts" :"Accounts"}</h2>
                    <TableContainer>
                        <PrimeDataTable columns={columns} data={actionableTasks} loading={loading} error={error} pagination={true} />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 32 }}>
                            <button
                                style={{
                                    background: '#7c3aed',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: 12,
                                    padding: '10px 36px',
                                    fontWeight: 600,
                                    fontSize: '1rem',
                                    boxShadow: '0 2px 8px rgba(124,58,237,0.10)',
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    outline: 'none',
                                }}
                                onClick={() => navigate('/')}
                            >
                                Back
                            </button>
                        </div>
                    </TableContainer>
                </div>
            </div>
        </div>
    )
}

export default Account