/**
 * @file Dashboard.jsx
 * @summary Dashboard component for Blythedale Children's Hospital
 * @description This component displays the dashboard for the Blythedale Children's Hospital
 * @since Jan 15, 2025
 */

import React, { useState, useEffect } from 'react';
import "./Dashboard.css";
import TableContainer from '../components/common/TableContainer';
import dashboardData from '../api/dashboardData';
import PrimeDataTable from '../components/common/PrimeDataTable';
import NavigationLink from "../components/common/NavigationLink";
import { getAgingAccountSummary, getDenialAlertData } from "../api/agingRepository";

function Dashboard({handleUserDropDown}) {
  const {
    taskSummary,
    accountsReceivable,
    denials,
    insurerTracker,
    openClaims,
    renewals,
    paymentVariance
  } = dashboardData;

  const [agingDatas, setAgingDatas] = useState([]);
  const [denialDatas, setDenialDatas] = useState([]);

  const [agingLoading, setAgingLoading] = useState(false);
  const [denialLoading, setDenialLoading] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setAgingLoading(true);
      setDenialLoading(true);

      const [agingData, denialData] = await Promise.all([
        getAgingAccountSummary(),
        getDenialAlertData()
      ]);

      if (agingData) setAgingDatas(agingData);
      if (denialData) setDenialDatas(denialData);

    } catch (error) {
      console.error("Dashboard data fetch failed:", error);
    } finally {
      setAgingLoading(false);
      setDenialLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    handleUserDropDown(true);
  }, []);

  useEffect(() => {
    const userChangeHandler = async () => {
      await fetchDashboardData();
    };

    window.addEventListener("reloadDashboardEvent", userChangeHandler);

    return () => {
      window.removeEventListener("reloadDashboardEvent", userChangeHandler);
    };
  }, []);

  const modifiedAgingColumns = accountsReceivable.columns.map((col) => {
    if (col.field === 'Claims') {
      return {
        ...col,
        body: (rowData) => (
          <NavigationLink
            label={rowData.Claims}
            state={{ aging: rowData.Aging, url: 'account' }}
            title="View aging account details"
          />
        )
      };
    }
    return col;
  });

  const modifiedDenialColumns = denials.columns.map((col) => {
    if (col.field === 'count') {
      return {
        ...col,
        body: (rowData) => (
          <NavigationLink
            label={rowData.count}
            state={{ DenialCode: rowData.DenialCode, url: 'denial/alerts2' }}
            title="View denial alert details"
          />
        )
      };
    }
    return col;
  });

  return (
    <div className="main">
      <div className="content">
        <div className="container py-4">
          <h2 className="mb-4 fw-bold">Billing Navigator</h2>
          <div className="row">
            {/* Left Column */}
            <div className="col-md-7">
              <TableContainer title={taskSummary.title}>
                <PrimeDataTable
                  columns={taskSummary.columns}
                  data={taskSummary.rows}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={insurerTracker.title}>
                <PrimeDataTable
                  columns={insurerTracker.columns}
                  data={insurerTracker.rows}
                  pagination={false}
                />
              </TableContainer>
            </div>

            {/* Right Column */}
            <div className="col-md-5">
              <TableContainer title={accountsReceivable.title}>
                <PrimeDataTable
                  columns={modifiedAgingColumns}
                  data={agingDatas}
                  loading={agingLoading}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={denials.title}>
                <PrimeDataTable
                  columns={modifiedDenialColumns}
                  data={denialDatas}
                  loading={denialLoading}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={openClaims.title}>
                <PrimeDataTable
                  columns={openClaims.columns}
                  data={openClaims.rows}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={paymentVariance.title}>
                <PrimeDataTable
                  columns={paymentVariance.columns}
                  data={paymentVariance.rows}
                  pagination={false}
                />
              </TableContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
