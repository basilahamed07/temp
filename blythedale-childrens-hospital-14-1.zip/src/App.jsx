import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import BillingOverview from './components/BillingOverview/BillingOverview.jsx';
import InsuranceProviderInsights from './components/InsuranceProviderInsights/InsuranceProviderInsights.jsx';
import DelayDurationCategories from './components/DelayDurationCategories/DelayDurationCategories.jsx';
import DelayReasonBreakdown from './components/DelayReasonBreakdown/DelayReasonBreakdown.jsx';
import InsuranceDelayReasonSummary from './components/InsuranceDelayReasonSummary/InsuranceDelayReasonSummary.jsx';
import ChatbotFloat from './components/common/ChatbotFloatButton.jsx';

function App() {
  const [activeTab, setActiveTab] = useState(0);

  const renderTab = () => {
    switch (activeTab) {
      case 0:
        return <BillingOverview />;
      case 1:
        return <InsuranceProviderInsights />;
      case 2:
        return <DelayDurationCategories />;
      case 3:
        return <DelayReasonBreakdown />;
      case 4:
        return <InsuranceDelayReasonSummary />;
      default:
        return null;
    }
  };

  return (
    <>
    <div style={{ minHeight: '100vh', width: '100vw', background: '#fafbfc', display: 'flex' }}>
      <Sidebar />
      <div style={{ flex: 1, minWidth: 0, paddingLeft: '180px' }}>
        <TopBar activeTab={activeTab} onTabChange={setActiveTab} />
        {renderTab()}
      </div>
    </div>
      <ChatbotFloat />
    </>
  );
}

export default App;
