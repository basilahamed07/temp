import React, { useState, useEffect } from 'react';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import styles from '../../styles/BillingOverview.module.css';
import axios from 'axios';
import PrimeDataTable from '../common/PrimeDataTable';
import CommonPieChart, { CommonPieLegend } from '../common/CommonPieChart';
import { getLightAndStrongColorByIndex } from '../../utility/colorUtils';
import billingOverviewMetricsData from '../../data/billingOverviewMetricsData.json';
import billingOverviewTableData from '../../data/billingOverviewTableData.json';

const BillingOverview = () => {
  const [view, setView] = useState('table');
  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [metricGroups, setMetricGroups] = useState([]);

  const API_BASE_URL = import.meta.env.VITE_API_URL;

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${API_BASE_URL}/payment-status-summary`);
      setRowData(response.data);
    } catch (err) {
      // Use local JSON for testing
      setRowData(billingOverviewTableData);
      setError(null); // Clear error since we have fallback data
    } finally {
      setLoading(false);
    }
  };

  const fetchMetricsData = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/overall-billing-metrics`);
      if (response.data && Array.isArray(response.data)) {
        setMetricGroups(response.data);
      } else {
        setMetricGroups([]);
      }
    } catch (err) {
      // Use local JSON for testing
      if (Array.isArray(billingOverviewMetricsData)) {
        setMetricGroups(billingOverviewMetricsData);
      } else {
        setMetricGroups([]);
      }
    }
  };

  // Fetch metrics and table data on mount
  useEffect(() => {
    fetchData();
    fetchMetricsData();
  }, []);

  // No frontend filtering, just use rowData
  const filteredData = rowData;

  // Map type to style classes
  const typeToCardClass = {
    patients: styles.cardBlue,
    accounts: styles.cardPurple,
    processed: styles.cardRed,
    posted: styles.cardYellow,
    reversed: styles.cardGreen,
    bills_lt_30: styles.cardYellow,
    bills_gt_30: styles.cardGreen,
  };
  const typeToValueClass = {
    patients: styles.metricValueBlue,
    accounts: styles.metricValuePurple,
    processed: styles.metricValueRed,
    posted: styles.metricValueYellow,
    reversed: styles.metricValueGreen,
    bills_lt_30: styles.metricValueYellow,
    bills_gt_30: styles.metricValueGreen,
  };

  const columns = [
    { field: 'status', header: 'Payment Status' },
    { field: 'bills', header: 'Number of Bills' },
    { field: 'amount', header: 'Total Amount' },
  ];

  return (
    <div className={styles.mainContainerWithTopMargin}>
      {/* Metric Cards */}
      {Array.isArray(metricGroups) && metricGroups[0]?.metrics && metricGroups[1]?.metrics ? (
        <div className="row g-2 mb-4">
          {/* Key Billing Metrics */}
          <div className="col-12 col-lg-7">
            <div className="card h-100">
              <div className="card-body">
                <div className={styles.metricsTitle}>{metricGroups[0]?.title || 'Key Billing Metrics'}</div>
                <div className="row g-2">
                  {(() => {
                    const metrics = metricGroups[0].metrics;
                    return metrics.map((metric, idx) => {
                      if (idx < 3) {
                        return (
                          <div className="col-12 col-md-4" key={idx}>
                            <div className={`card border-0 shadow-sm ${typeToCardClass[metric.type]} ${styles.metricCard}`}> 
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span className={typeToValueClass[metric.type]} style={{ display: 'block', textWrap: 'wrap' }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      } else {
                        // Use generated light/strong color for background and value text
                        const { light, strong } = getLightAndStrongColorByIndex(idx, metrics.length);
                        return (
                          <div className="col-12 col-md-4" key={idx}>
                            <div className={`card border-0 shadow-sm ${styles.metricCard}`} style={{ background: light }}>
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span style={{
                                  display: 'block',
                                  color: strong,
                                  fontWeight: 600,
                                  fontSize: '40px',
                                  textAlign: 'center',
                                  width: '100%',
                                  textWrap: 'wrap'
                                }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    });
                  })()}
                </div>
              </div>
            </div>
          </div>
          {/* Duration Based Billing Summary */}
          <div className="col-12 col-lg-5">
            <div className="card h-100">
              <div className="card-body">
                <div className={styles.metricsTitle}>{metricGroups[1]?.title || 'Duration Based Billing Summary'}</div>
                <div className="row g-2">
                  {(() => {
                    const metrics = metricGroups[1].metrics;
                    return metrics.map((metric, idx) => {
                      if (idx < 2) {
                        return (
                          <div className="col-12 col-md-6" key={idx}>
                            <div className={`card border-0 shadow-sm ${typeToCardClass[metric.type]} ${styles.metricCard}`}> 
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span className={typeToValueClass[metric.type]} style={{ display: 'block', textWrap: 'wrap' }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      } else {
                        // Use generated light/strong color for background and value text
                        const { light, strong } = getLightAndStrongColorByIndex(idx, metrics.length);
                        return (
                          <div className="col-12 col-md-6" key={idx}>
                            <div className={`card border-0 shadow-sm ${styles.metricCard}`} style={{ background: light }}>
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span style={{
                                  display: 'block',
                                  color: strong,
                                  fontWeight: 600,
                                  fontSize: '40px',
                                  textAlign: 'center',
                                  width: '100%',
                                  textWrap: 'wrap'
                                }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    });
                  })()}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div></div>
      )}
      {/* Filter & Summary by Payment Status */}
      <div className={styles.summaryTitle}>Summary by Payment Status</div>
      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body pb-0 pt-0">
          <div className="row align-items-center">
            <div className="col d-flex align-items-center flex-wrap gap-2">
            </div>
            <div className="col-auto">
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className={view === 'table' ? `${styles.tabButton} ${styles.tabButtonActive}` : styles.tabButton}
                  onClick={() => setView('table')}
                  style={{ fontSize: '16px', fontFamily: 'inherit', fontWeight: 500 }}
                >
                  Table
                </button>
                <button
                  className={view === 'pie' ? `${styles.tabButton} ${styles.tabButtonActive}` : styles.tabButton}
                  onClick={() => setView('pie')}
                  style={{ fontSize: '16px', fontFamily: 'inherit', fontWeight: 500 }}
                >
                  Pie Chart
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          {loading ? (
            <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          ) : error ? (
            <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
              Sorry, we couldn't load your data right now. Please try again later.
            </div>
          ) : view === 'table' ? (
            <PrimeDataTable columns={columns} data={filteredData} loading={loading} error={error} />
          ) : (
            <CommonPieChart
              data={Array.isArray(filteredData) ? filteredData : []}
              dataKey="bills"
              nameKey="status"
              tooltipContent={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const d = payload[0]?.payload;
                  return (
                    <div style={{ padding: 12, background: '#fff', borderRadius: 14, boxShadow: '0 2px 12px #0001', fontWeight: 600, fontSize: 15 }}>
                      {d?.status} : {d?.bills}
                    </div>
                  );
                }
                return null;
              }}
              renderLegend={(data, colors, activeIndex, setActiveIndex) =>
                CommonPieLegend(data, colors, activeIndex, setActiveIndex, {
                  labelField: 'status',
                  valueField: 'amount',
                  subValueField: 'bills',
                  valueFormatter: v => v,
                  subValueFormatter: v => `No of Bills: ${v}`
                })
              }
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default BillingOverview; 