import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CommonBarChart, { getBarTooltip } from '../common/CommonBarChart';
import styles from '../../styles/DelayDurationCategories.module.css';

const tooltipContent = getBarTooltip({
  titleFn: d => `Duration Category: ${d.category}`,
  label1: 'Percentage',
  value1Fn: d => `${d.percent}%`,
  label2: '',
  value2Fn: () => '',
});

const DelayDurationCategories = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const API_BASE_URL = import.meta.env.VITE_API_URL;
        const res = await axios.get(`${API_BASE_URL}/duration-category-summary`);
        if (Array.isArray(res.data)) {
          setData(res.data);
        } else {
          setData([]);
        }
      } catch (err) {
        setError('Failed to load data.');
        setData([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Dynamically generate yAxisTicks based on data
  const max = Math.max(...(Array.isArray(data) ? data.map(d => d.count) : [0]), 0);
  const step = 2000;
  const yAxisTicks = Array.from({ length: Math.ceil(max / step) + 1 }, (_, i) => i * step);

  return (
    <div className={styles.container}>
      {loading ? (
        <div className={styles.loadingContainer}>
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
          Sorry, we couldn't load your data right now. Please try again later.
        </div>
      ) : (
        <CommonBarChart
          data={Array.isArray(data) ? data : []}
          yAxisLabel='No of Bills'
          title='Distribution of Delay Days'
          yAxisTicks={yAxisTicks}
          tooltipContent={tooltipContent}
        />
      )}
    </div>
  );
};

export default DelayDurationCategories; 