import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CommonBarChart, { getBarTooltip } from '../common/CommonBarChart';
import styles from '../../styles/DelayReasonBreakdown.module.css';

const tooltipContent = getBarTooltip({
  titleFn: d => `Reason: ${d.reason}`,
  label1: 'Percentage',
  value1Fn: d => `${d.percent}%`,
  label2: '',
  value2Fn: () => '',
});

const DelayReasonBreakdown = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const pageSize = 5;
  const totalPages = Math.ceil(data.length / pageSize);
  const pagedData = data.slice(page * pageSize, (page + 1) * pageSize);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const API_BASE_URL = import.meta.env.VITE_API_URL;
        const res = await axios.get(`${API_BASE_URL}/Reason-delay-summary`);
        let apiData = Array.isArray(res.data) ? res.data : [];
        // Sort by count descending
        apiData = apiData.sort((a, b) => (b.count || 0) - (a.count || 0));
        setData(apiData);
      } catch (err) {
        setError('Failed to load data.');
        setData([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Dynamically generate yAxisTicks based on data
  const max = Math.max(...(Array.isArray(data) ? data.map(d => d.count) : [0]), 0);
  const step = 50;
  const yAxisTicks = Array.from({ length: Math.ceil(max / step) + 1 }, (_, i) => i * step);

  return (
    <div className={styles.container}>
      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
          Sorry, we couldn't load your data right now. Please try again later.
        </div>
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div style={{ fontWeight: 600, fontSize: 22 }}>
              {`Delay Reasons (${page * pageSize + 1}-${Math.min((page + 1) * pageSize, data.length)} of ${data.length})`}
            </div>
            <div>
              <button
                className={page === 0 ? `${styles.paginationButton}` : `${styles.paginationButton} ${styles.paginationButtonActive}`}
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                Previous
              </button>
              <span style={{ alignSelf: 'center', margin: '0 8px' }}>Page {page + 1} of {totalPages}</span>
              <button
                className={page >= totalPages - 1 ? `${styles.paginationButton}` : `${styles.paginationButton} ${styles.paginationButtonActive}`}
                onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
              >
                Next
              </button>
            </div>
          </div>
          <CommonBarChart
            data={Array.isArray(pagedData) ? pagedData : []}
            xAxisKey="reason"
            yAxisLabel="Number of Occurrences"
            title={''}
            yAxisTicks={yAxisTicks}
            tooltipContent={tooltipContent}
          />
        </>
      )}
    </div>
  );
};

export default DelayReasonBreakdown; 