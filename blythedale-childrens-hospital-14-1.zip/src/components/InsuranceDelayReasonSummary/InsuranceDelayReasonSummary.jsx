import React, { useState, useEffect } from 'react';
import CommonBarChart from '../common/CommonBarChart';
import styles from '../../styles/InsuranceDelayReasonSummary.module.css';
import axios from 'axios';
import Select from 'react-select';
import { generateColors } from '../../utility/colorUtils';
import insuranceDelayReasonSummaryData from '../../data/insuranceDelayReasonSummaryData.json';
import { marked } from 'marked';

function formatMarkdown(text) {
  try {
    if (typeof text !== 'string') return '';
    return marked.parse(text);
  } catch (err) {
    return typeof text === 'string' ? text.replace(/\n/g, '<br>') : '';
  }
}

const InsuranceDelayReasonSummary = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProvider, setSelectedProvider] = useState('');
  const [error, setError] = useState(false);

  const API_BASE_URL = import.meta.env.VITE_API_URL;

  // Get insurance providers from data (new JSON structure)
  const insuranceProviders = Array.isArray(data) ? data.map(d => d.insurance) : [];

  // Get selected provider's delay reasons for the bar chart
  const selectedProviderObj = Array.isArray(data) ? data.find(d => d.insurance === selectedProvider) || {} : {};
  let filteredBarData = selectedProviderObj && Array.isArray(selectedProviderObj.delayReasons) ? selectedProviderObj.delayReasons : [];

  // Calculate percent for each delay reason (for bar chart labels)
  if (Array.isArray(filteredBarData) && filteredBarData.length > 0) {
    const total = filteredBarData.reduce((sum, d) => sum + (d?.totalBills || 0), 0);
    filteredBarData = filteredBarData.map(d => ({
      ...d,
      percent: total ? ((d?.totalBills || 0) / total * 100).toFixed(1) : 0
    }));
  }

  // Pagination for Bar Chart tab (delayReasons)
  const [barPage, setBarPage] = useState(0);
  const barPageSize = 5;
  let pagedBarData = filteredBarData;
  let barTotalPages = 1;
  if (Array.isArray(filteredBarData)) {
    pagedBarData = [...filteredBarData].sort((a, b) => (b.totalBills || 0) - (a.totalBills || 0));
    barTotalPages = Math.ceil(pagedBarData.length / barPageSize);
    pagedBarData = pagedBarData.slice(barPage * barPageSize, (barPage + 1) * barPageSize);
  }

  // Assign consistent colors to each status using generateColors utility (for pagedBarData)
  const barColorPalette = generateColors(pagedBarData.length);
  const barStatusColorMap = {};
  pagedBarData.forEach((item, idx) => {
    if (item && item.status && !barStatusColorMap[item.status]) {
      barStatusColorMap[item.status] = barColorPalette[idx % barColorPalette.length];
    }
  });
  const coloredPagedBarData = pagedBarData.map(item => ({
    ...item,
    color: barStatusColorMap[item.status] || barColorPalette[0] || '#8fa8f8'
  }));

  // Dynamically generate yAxisTicks for bar chart
  const barMaxBar = Math.max(...(Array.isArray(filteredBarData) ? filteredBarData.map(d => d.totalBills) : [0]), 0);
  const barStepBar = 50;
  const barYAxisTicksBar = Array.from({ length: Math.ceil(barMaxBar / barStepBar) + 1 }, (_, i) => i * barStepBar);

  // Set default selected provider when data loads
  useEffect(() => {
    if (insuranceProviders?.length > 0 && !selectedProvider) {
      setSelectedProvider(insuranceProviders[0]);
    }
  }, [insuranceProviders, selectedProvider]);

  // Reset barPage to 0 when selectedProvider changes
  useEffect(() => { setBarPage(0); }, [selectedProvider]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(false);
      try {
        const response = await axios.get(`${API_BASE_URL}/insurances/delays`);
        if (response?.data && Array.isArray(response?.data) && response?.data?.length > 0) {
          setData(response?.data);
        } else {
          setData([]);
          setError(true);
        }
      } catch (err) {
        // Use local JSON for testing
        setData(Array.isArray(insuranceDelayReasonSummaryData) ? insuranceDelayReasonSummaryData : []);
        setError(false); // No error since we have fallback data
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className={`${styles.outerContainer} ${styles.outerContainerRelative}`}>
      {/* Bar chart and legend section only */}
      <div className={styles.chartScroll}>
        <div className={styles.chartRow}>
          <div className={`${styles.leftSection} ${styles.leftSectionNoPad}`}>
            {loading ? (
              <div style={{ minHeight: 120 }} className="d-flex justify-content-center align-items-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : error && (!data || data.length === 0) ? (
              <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
                Sorry, we couldn't load your data right now. Please try again later.
              </div>
            ) : (
              <div className={styles.top5DelayReasonsSection}>
                {/* Heading above dropdown */}
                <div className={`${styles.title} ${styles.titleNoPadding}`} style={{ marginBottom: 8 }}>
                  Delay Reasons for {selectedProvider}
                </div>
                {/* Dropdown for insurance provider selection */}
                <div className={styles.providerDropdownRow}>
                  <label htmlFor="insurance-provider-select" className={styles.providerDropdownLabel}>
                    Select an insurance provider:
                  </label>
                  <div style={{ minWidth: 220 }}>
                    <Select
                      inputId="insurance-provider-select"
                      classNamePrefix="select"
                      options={insuranceProviders?.map(p => ({ value: p, label: p }))}
                      value={insuranceProviders?.map(p => ({ value: p, label: p }))?.find(opt => opt.value === selectedProvider) || null}
                      onChange={opt => setSelectedProvider(opt ? opt.value : '')}
                      placeholder="Select insurance provider..."
                      isSearchable
                      menuPortalTarget={document.body}
                      styles={{ menuPortal: base => ({ ...base, zIndex: 2000 }) }}
                    />
                  </div>
                </div>
                {/* Pagination controls for bar chart */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                  <button
                    className={barPage === 0 ? styles.paginationButton : `${styles.paginationButton} ${styles.paginationButtonActive}`}
                    onClick={() => setBarPage(p => Math.max(0, p - 1))}
                    disabled={barPage === 0}
                    style={{ marginRight: 8 }}
                  >
                    Previous
                  </button>
                  <span style={{ alignSelf: 'center', margin: '0 8px' }}>Page {barPage + 1} of {barTotalPages}</span>
                  <button
                    className={barPage >= barTotalPages - 1 ? styles.paginationButton : `${styles.paginationButton} ${styles.paginationButtonActive}`}
                    onClick={() => setBarPage(p => Math.min(barTotalPages - 1, p + 1))}
                    disabled={barPage >= barTotalPages - 1}
                  >
                    Next
                  </button>
                </div>
                <CommonBarChart
                  data={Array.isArray(coloredPagedBarData) ? coloredPagedBarData : []}
                  xAxisKey="status"
                  yAxisKey="totalBills"
                  yAxisLabel="No of Bills"
                  title=""
                  yAxisTicks={barYAxisTicksBar}
                  tooltipContent={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload;
                      return (
                        <div className={styles.barTooltipBox}>
                          <div className={styles.barTooltipRow}>
                            <span className={styles.barTooltipLabel}>Primary Delay Reason :</span> <span className={styles.barTooltipValue}>{d.status}</span>
                          </div>
                          <div><span className={styles.barTooltipLabel}>Count :</span> <span className={styles.barTooltipValue}>{d.totalBills}</span></div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                {(selectedProviderObj.dos || selectedProviderObj.donts) && (
                  <div className={styles.dosDontsSection} style={{ paddingLeft: 32, paddingRight: 32 }}>
                    {selectedProviderObj.dos && (
                      <div>
                        <div className={styles.dosHeading}>Dos:</div>
                        <ul className={styles.dosDontsList}>
                          {selectedProviderObj.dos.split('\n').map((item, idx) => (
                            <li key={idx} dangerouslySetInnerHTML={{ __html: formatMarkdown(item.replace(/^\d+\.\s*/, '')) }} />
                          ))}
                        </ul>
                      </div>
                    )}
                    {selectedProviderObj.donts && (
                      <div>
                        <div className={styles.dontsHeading}>Don'ts:</div>
                        <ul className={styles.dosDontsList}>
                          {selectedProviderObj.donts.split('\n').map((item, idx) => (
                            <li key={idx} dangerouslySetInnerHTML={{ __html: formatMarkdown(item.replace(/^\d+\.\s*/, '')) }} />
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsuranceDelayReasonSummary; 