import React, { useState, useEffect } from 'react';
import styles from '../../styles/InsuranceProviderInsights.module.css';
import axios from 'axios';
import CommonPieChart, { CommonPieLegend } from '../common/CommonPieChart';
import sampleInsuranceProviderData from '../../data/sampleInsuranceProviderData.json';

const tabOptions = [
  'All',
  '< 30 Days',
  '\u2265 30 Days',
];

const InsuranceProviderInsights = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const API_BASE_URL = import.meta.env.VITE_API_URL;
        let endpoint = '/insurances/all-top-10';
        if (activeTab === 1) endpoint = '/insurances/less-30-days';
        if (activeTab === 2) endpoint = '/insurances/more-30-days';
        const response = await axios.get(`${API_BASE_URL}${endpoint}`);
        let apiData = Array.isArray(response.data) ? response.data : [];
        setData(apiData);
      } catch (err) {
        // Use local JSON for testing
        setData(Array.isArray(sampleInsuranceProviderData) ? sampleInsuranceProviderData : []);
        setError(null); // Clear error since we have fallback data
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [activeTab]);

  // Custom tooltip: show only insurance name and percent on one line
  const pieTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const d = payload[0].payload;
      return (
        <div style={{ padding: 12, background: '#fff', borderRadius: 14, boxShadow: '0 2px 12px #0001', fontWeight: 600, fontSize: 15 }}>
          {d.insurance} {d.percent}%
        </div>
      );
    }
    return null;
  };


  return (
    <div className={styles.container}>
      <div className={styles.title}>Top 10 Insurance Providers</div>
      <div className={styles.tabBar}>
        {tabOptions.map((tab, idx) => (
          <button
            key={tab}
            className={activeTab === idx ? styles.activeTab : styles.tabBtn}
            onClick={() => setActiveTab(idx)}
            {...(activeTab === idx ? { className: styles.activeTab + ' ' + styles.tabBtnCustomFont } : { className: styles.tabBtn + ' ' + styles.tabBtnCustomFont })}
          >
            {tab}
          </button>
        ))}
      </div>
      {/* Only show filter/download in last tab */}
      <div className={styles.tableWrapper}>
        {loading ? (
          <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : error ? (
          <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
            Sorry, we couldn't load your data right now. Please try again later.
          </div>
        ) : data && data.length > 0 ? (
          <CommonPieChart
            data={data}
            dataKey="percent"
            nameKey="insurance"
            tooltipContent={pieTooltip}
            renderLegend={(data, colors, activeIndex, setActiveIndex) =>
              CommonPieLegend(
                data,
                colors,
                activeIndex,
                setActiveIndex,
                {
                  labelField: 'insurance',
                  valueField: 'percent',
                  valueFormatter: v => `${v}%`
                }
              )
            }
          />
        ) : (
          <div className={styles.emptyState}>No data available</div>
        )}
      </div>
    </div>
  );
};

export default InsuranceProviderInsights; 