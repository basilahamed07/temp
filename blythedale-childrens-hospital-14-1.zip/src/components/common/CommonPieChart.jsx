import React, { useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import styles from '../../styles/CommonPieChart.module.css';
import { generateColors } from '../../utility/colorUtils';

export const CommonPieLegend = (
  data,
  colors,
  activeIndex,
  setActiveIndex,
  {
    labelField = 'name',
    valueField = 'value',
    subValueField = null,
    valueFormatter = v => v,
    subValueFormatter = v => v
  } = {}
) => {
  if (!Array.isArray(data) || data.length === 0) return null;
  const mid = Math.ceil(data.length / 2);
  const firstCol = data.slice(0, mid);
  const secondCol = data.slice(mid);

  const renderLegendItem = (entry, idx, legendIdx) => {
    const isActive = activeIndex === null || activeIndex === legendIdx;
    return (
      <div
        key={`${entry[labelField] || entry.name || idx}-${legendIdx}`}
        onMouseEnter={() => setActiveIndex(legendIdx)}
        onMouseLeave={() => setActiveIndex(null)}
        className={styles.legendItem}
        style={{
          opacity: isActive ? 1 : 0.5,
          fontWeight: activeIndex === legendIdx ? 700 : 400,
          color: activeIndex === legendIdx ? '#222' : '#aaa',
          cursor: 'pointer'
        }}
      >
        <span className={styles.legendDot} style={{ background: colors[legendIdx % colors.length] }} />
        <div>
          <div className={styles.legendLabel} style={{ color: colors[legendIdx % colors.length] }}>
            {entry[labelField] || entry.name}
          </div>
          <div className={styles.legendValue}>
            {valueField && entry[valueField] !== undefined && (
              <b>{valueFormatter(entry[valueField])}</b>
            )}
            {subValueField && entry[subValueField] !== undefined && (
              <>
                <br />
                <span>{subValueFormatter(entry[subValueField])}</span>
              </>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className={styles.legendColumn}>
        {firstCol.map((entry, idx) => renderLegendItem(entry, idx, idx))}
      </div>
      <div className={styles.legendColumn}>
        {secondCol.map((entry, idx) => renderLegendItem(entry, idx, mid + idx))}
      </div>
    </>
  );
};

const CommonPieChart = ({ data, dataKey, nameKey, colors, renderLegend, tooltipContent }) => {
  const [activeIndex, setActiveIndex] = useState(null);

  // Safety: Only render chart if data is a non-empty array
  if (!Array.isArray(data) || data.length === 0) {
    return <div className={styles.pieChartOuterScroll}><div className={styles.pieChartContainer}><div style={{textAlign:'center',padding:'2rem',color:'#888'}}>No data available</div></div></div>;
  }

  // Generate colors if not provided
  const pieColors = (Array.isArray(colors) && colors.length === data.length)
    ? colors
    : generateColors(data.length);

  return (
    <div className={styles.pieChartOuterScroll}>
      <div className={styles.pieChartContainer}>
        <div className={styles.pieChartArea}>
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={data}
                dataKey={dataKey}
                nameKey={nameKey}
                cx="50%"
                cy="50%"
                innerRadius={90}
                outerRadius={160}
                fill="#8884d8"
                label={false}
                onMouseLeave={() => setActiveIndex(null)}
                onMouseEnter={(_, idx) => setActiveIndex(idx)}
              >
                {data?.map((entry, idx) => {
                  const isActive = activeIndex === null || activeIndex === idx;
                  return (
                    <Cell
                      key={`cell-${idx}`}
                      fill={pieColors[idx % pieColors.length]}
                      opacity={isActive ? 1 : 0.5}
                    />
                  );
                })}
              </Pie>
              <Tooltip content={tooltipContent} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className={styles.legendGrid}>
          {renderLegend && renderLegend(data, pieColors, activeIndex, setActiveIndex)}
        </div>
      </div>
    </div>
  );
};

export default CommonPieChart; 