import React, { useState } from 'react';

function ErrorBoundary({ children }) {
  const [hasError, setHasError] = useState(false);

  // Custom error handler for functional components
  function errorHandler(error, errorInfo) {
    setHasError(true);
  }

  // Wrap children in a try-catch using a helper
  let content;
  try {
    if (hasError) {
      content = (
        <div style={{ padding: 32, color: '#b71c1c', background: '#fff3f3', borderRadius: 8, textAlign: 'center' }}>
          <h2>Sorry, something went wrong.</h2>
          <div>Please try again later. If the problem persists, contact support.</div>
        </div>
      );
    } else {
      content = React.Children.only(children);
    }
  } catch (error) {
    errorHandler(error, {});
    content = (
      <div style={{ padding: 32, color: '#b71c1c', background: '#fff3f3', borderRadius: 8, textAlign: 'center' }}>
        <h2>Sorry, something went wrong.</h2>
        <div>Please try again later. If the problem persists, contact support.</div>
      </div>
    );
  }

  return content;
}

export default ErrorBoundary; 