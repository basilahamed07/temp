const dashboardData = {
  problematicAccount: {
      title: "Top 5 Problematic Accounts",
      columns: [
        { field: "AccountNumber", header: "Account Number", sortable: false },
        { field: "Duration", header: "Duration", sortable: false },
        { field: "Amount", header: "Amount", sortable: false },
        { field: "AIRecommendationAction", header: "AI Recommendation   Action", sortable: false }
      ],
      rows: [
        {
          AccountNumber: "Appeals Due (Within 3 Days)",
          Duration: 9,
          Amount: "High",
        },
        {
          AccountNumber: "Appeals Due (Within 3 Days)",
          Duration: 9,
          Amount: "High",
        },
        {
          AccountNumber: "Appeals Due (Within 3 Days)",
          Duration: 9,
          Amount: "High",
        },
        {
          AccountNumber: "Appeals Due (Within 3 Days)",
          Duration: 9,
          Amount: "High",
        },
        {
          AccountNumber: "Appeals Due (Within 3 Days)",
          Duration: 9,
          Amount: "High",
        }
      ]
    },
    accountsReceivable: {
      title: "Aging Accounts Receivable Summary",
      columns: [
        { field: "Aging", header: "Aging", sortable: false, width: '10%' },
        { field: "Amount", header: "Amount ($)", sortable: false, width: '10%' },
        { field: "Claims", header: "Claims", sortable: false, width: '10%' },
        { field: "Priority", header: "Priority", sortable: false, width: '10%' }
      ]
    },
    denials: {
      title: "Denial Alerts & Resolution Tracker",
      columns: [
        { field: "DenialCodes", header: "Denial Code", sortable: false },
        { field: "Description", header: "Description", sortable: false },
        { field: "AccountCount", header: "Count", sortable: false },
      ]
    },
    insurerTracker: {
      title: "Insurer Issue Tracker",
      columns: [
        { field: "insurer", header: "Insurer", sortable: false },
        { field: "issue", header: "Recurring Issue", sortable: false },
        { field: "claims", header: "Count", sortable: false },
        { field: "recommendation", header: "Action Recommendation", sortable: false }
      ],
      rows: [
        {
          insurer: "MCD",
          issue: "Over-limit therapy denials",
          claims: 7,
          trend: "Rising",
          recommendation: "Submit frequency override request"
        },
        {
          insurer: "HFHSP",
          issue: "Missing authorization details",
          claims: 5,
          trend: "Rising",
          recommendation: "Match EMR and claim auth data"
        },
        {
          insurer: "Aetna",
          issue: "OT/ST claims missing modifiers",
          claims: 6,
          trend: "Stable",
          recommendation: "Re-train team on proper modifier usage"
        },
        {
          insurer: "EMPBCCON",
          issue: "Neuro PT marked as non-covered",
          claims: 4,
          trend: "Falling",
          recommendation: "Confirm coverage in benefits portal"
        },
        {
          insurer: "BENEXHAUST",
          issue: "NPI/taxonomy code mismatch",
          claims: 3,
          trend: "Rising",
          recommendation: "Correct taxonomy in claim profile"
        },
        {
          insurer: "MCD",
          issue: "Over-limit therapy denials",
          claims: 7,
          trend: "Rising",
          recommendation: "Submit frequency override request"
        },
        {
          insurer: "HFHSP",
          issue: "Missing authorization details",
          claims: 5,
          trend: "Rising",
          recommendation: "Match EMR and claim auth data"
        },
        {
          insurer: "Aetna",
          issue: "OT/ST claims missing modifiers",
          claims: 6,
          trend: "Stable",
          recommendation: "Re-train team on proper modifier usage"
        },
        {
          insurer: "EMPBCCON",
          issue: "Neuro PT marked as non-covered",
          claims: 4,
          trend: "Falling",
          recommendation: "Confirm coverage in benefits portal"
        },
        {
          insurer: "BENEXHAUST",
          issue: "NPI/taxonomy code mismatch",
          claims: 3,
          trend: "Rising",
          recommendation: "Correct taxonomy in claim profile"
        }
      ]
    },
    openClaims: {
      title: "Open Claims",
      columns: [
        { field: "accountNumber", header: "Account Number", sortable: false },
        { field: "documentNeeded", header: "Document Needed", sortable: false },
        { field: "assignedTo", header: "Assigned To", sortable: false },
        { field: "followUpDate", header: "Follow-up Date", sortable: false }
      ],
      rows: [
        {
          accountNumber: "V00000164385",
          documentNeeded: "Progress Notes (PT)",
          assignedTo: "Rehab Dept",
          followUpDate: "07/19/2025"
        },
        {
          accountNumber: "V00000162930",
          documentNeeded: "Pre-auth Form",
          assignedTo: "Front Desk",
          followUpDate: "07/20/2025"
        }
      ]
    },
    renewals: {
      title: "Upcoming Authorizations for Renewal",
      columns: [
        { field: "patientId", header: "Patient ID", sortable: false },
        { field: "name", header: "Name", sortable: false },
        { field: "service", header: "Service", sortable: false },
        { field: "expiryDate", header: "Expiry Date", sortable: false },
        { field: "status", header: "Status", sortable: false }
      ],
      rows: [
        {
          patientId: "EO-B2023103015438441",
          name: "Emily R.",
          service: "OT (Neuro)",
          expiryDate: "07/19/2025",
          status: "Not Initiated"
        },
        {
          patientId: "EO-B2023071514430872",
          name: "Noah M.",
          service: "Ortho",
          expiryDate: "07/20/2025",
          status: "Request in Draft"
        },
        {
          patientId: "EO-B2024071013000987",
          name: "Ava L.",
          service: "Occupational Therapy",
          expiryDate: "07/22/2025",
          status: "Awaiting documentation"
        }
      ]
    },
    paymentVariance: {
      title: "Payment Variance",
      columns: [
        { field: "claimId", header: "Claim ID", sortable: false },
        { field: "expected", header: "Expected ($)", sortable: false },
        { field: "paid", header: "Paid ($)", sortable: false },
        { field: "variance", header: "Variance ($)", sortable: false },
        { field: "status", header: "Status", sortable: false }
      ],
      rows: [
        {
          claimId: "CO-50",
          expected: 3900,
          paid: 2200,
          variance: 1700,
          status: "Pending Review"
        },
        {
          claimId: "CO-109",
          expected: 5300,
          paid: 2000,
          variance: 3300,
          status: "Appeal Required"
        },
        {
          claimId: "CO-16",
          expected: 2100,
          paid: 1800,
          variance: 300,
          status: "Correction Sent"
        }
      ]
    }
  };
   
  export default dashboardData;