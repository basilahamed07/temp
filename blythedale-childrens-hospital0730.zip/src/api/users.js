import axios from "axios";
 
export const getUsers = async () => {
    
   
    try {
        if(import.meta.env.VITE_USE_JSON_DB){
            let API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/users`; // Adjust this path if needed
            const response = await axios.get(API_URL); 
            console.log("Response from JSON DB:", response);
            return response;
        }
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/users/unique`;
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    }
};