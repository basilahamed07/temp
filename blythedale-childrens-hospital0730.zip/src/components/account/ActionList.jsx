import React from "react";
import { TbBulb } from "react-icons/tb";

const ActionList = ({ actionListData }) => {

  return (
    <div className="card h-100 shadow-sm">
      <div className="card-header text-white fw-semibold py-4 rounded bg-purple">
        Action List
      </div>
      <div className="card-body small pt-1" style={{ height: '300px', overflowY: 'auto' }}>
        {actionListData && actionListData.map((data) => (
          <div className="mb-4">
            <div className="d-flex align-items-start">
              <div className="me-2">
                <TbBulb
                  size={32}
                  style={data.status === 'Completed' ? { color: 'green' } : undefined}
                />
              </div>
              <div>
                <strong>{data.step}</strong><br />
                <small>{data.description}</small>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActionList;
