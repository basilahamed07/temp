import React from "react";
import './Timeline.css';
const Timeline = ({ timelineData }) => {
  return (
    <div className="card h-100 shadow-sm mb-4">
      <div className="card-header bg-purple text-white rounded shadow-header">Timeline</div>
      <div className="card-body small p-0">
        <div className="row gx-0 p-1 pb-2 mb-2 fw-bold">
          <div className="col-6">Time</div>
          <div className="col-6">Activity</div>          
        </div>
        {/* <div className="row timeline-elements gx-0 p-1"> */}
        <div className="row gx-0 p-1">
          {timelineData.map((data, idx) => (
            <div key={idx} className="row gx-0 mb-1 pe-0">
              <div className="col-4 pe-0">
                <small>{data.Time}</small>
              </div>
              <div className="col-8 pe-0">
                <small>{data.Activity}</small>
              </div>              
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Timeline;
