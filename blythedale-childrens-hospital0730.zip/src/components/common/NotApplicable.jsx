import React from 'react';

const NotApplicable = () => {
    return (
        <span><small>NA</small></span>
    )
}
export default NotApplicable;