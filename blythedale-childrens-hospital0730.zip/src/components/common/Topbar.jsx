import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Topbar.css";
import { FaRegUserCircle } from "react-icons/fa";
import { getUsers } from "../../api/users";

const Topbar = ({showUserDropDown}) => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(
    localStorage.getItem("selectedUser") || ""
  );
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  const toggleDropdown = () => {
    setDropdownOpen((prev) => !prev);
  };

  const handleUserClick = (name) => {
    setSelectedUser(name);
    setDropdownOpen(false);
    localStorage.setItem("selectedUser", name);

    const event = new CustomEvent("reloadDashboardEvent", {
      detail: { selectedUser: name },
    });

    window.dispatchEvent(event);
  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await getUsers();
        const userList = response?.data?.unique_users || [];
        setUsers(userList);

        if (!localStorage.getItem("selectedUser") && userList.length > 0) {
          setSelectedUser(userList[0]);
          localStorage.setItem("selectedUser", userList[0]);
        }
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
    console.log("SelectedUser:", selectedUser);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="topbar">
      <div className="angled-box">
        <Link to="/">
          <img src="/blythedale-childrens-hospital.png" alt="Logo" />
        </Link>
      </div>
      <div className="user-info" ref={dropdownRef}>
        <span onClick={toggleDropdown}>{selectedUser}</span>
        <img
          src="https://i.pravatar.cc/150?img=32"
          alt="Profile"
          onClick={toggleDropdown}
          style={{ cursor: "pointer" }}
        />
        {showUserDropDown && dropdownOpen && (
          <div className="user-dropdown">
            {users.map(
              (name) =>
                name !== selectedUser && (
                  <div
                    key={name}
                    onClick={() => handleUserClick(name)}
                    className="dropdown-item"
                    title={name}
                  >
                    <FaRegUserCircle className="user-dropdown-icon" />
                    <span className="dropdown-user-name">{name}</span>
                  </div>
                )
            )}
          </div>
        )}
      </div>
      <div className="top-bar-spacer"></div>
    </div>
  );
};

export default Topbar;
