import React, { useEffect, useState } from "react";
import { useLocation } from 'react-router-dom';
import './Account.css';
import Stepper from "../components/account/Stepper";
import SummaryCard from "../components/account/SummaryCard";
import ActionList from "../components/account/ActionList";
import Timeline from "../components/account/Timeline";
import DocumentsList from "../components/account/DocumentsList";
import { getBillDetails } from "../api/billApi";

const Account = ({handleUserDropDown}) => {
    const location = useLocation();
    const AccountNumber = location.state?.AccountNumber
    const BillNo = location.state?.BillNo
    const [billDetails, setBillDetails] = useState(null);
    const fetchBillDetails = async () => {
        try {
            const response = await getBillDetails(AccountNumber, BillNo);
            setBillDetails(response.data);
        } catch (error) {
            console.error("Error fetching bill details:", error);
        }
    };
    useEffect(() => {
        fetchBillDetails();
        handleUserDropDown(false);
    }, []);

    if (!billDetails) return <div>Loading...</div>;

    return (
        <div className="main">
            <div className="content">
                <div className="container">
                    <header>
                        <h6 className="mb-2">Billing Navigator</h6>
                    </header>

                    {/* <Stepper currentStep={0} AccountNumber={AccountNumber} /> */}

                    {/* <header className="mt-4 mb-3">
                        <h6>Claims Processing Tracker</h6>
                    </header> */}

                    <div className="row g-4">
                        <div className="col-lg-4"><SummaryCard billDetails={billDetails} /></div>
                        <div className="col-lg-4">
                            <ActionList actionListData={ billDetails?.ActionList || null } />
                        </div>
                        <div className="col-lg-4">
                            <Timeline timelineData={billDetails?.Timeline} />
                            {/* <DocumentsList /> */}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Account;
