/**
 * @file Dashboard.jsx
 * @summary Dashboard component for Blythedale Children's Hospital
 * @description This component displays the dashboard for the Blythedale Children's Hospital
 * @since Jan 15, 2025
 */

import React, { useState, useEffect } from 'react';
import "./Dashboard.css";
import TableContainer from '../components/common/TableContainer';
import dashboardData from '../api/dashboardData';
import PrimeDataTable from '../components/common/PrimeDataTable';
import NavigationLink from "../components/common/NavigationLink";
import { getAgingAccountSummary, getDenialAlertData, getProblematicData } from "../api/agingRepository";
import { Dialog } from "primereact/dialog";
import DialogHeader from '../components/common/DialogHeader';
import { getGeneratedData } from '../api/billApi';
import { ProgressSpinner } from 'primereact/progressspinner';

function Dashboard({ handleUserDropDown }) {
  const {
    problematicAccount,
    accountsReceivable,
    denials,
    insurerTracker,
    openClaims,
    renewals,
    paymentVariance
  } = dashboardData;
  const selectedUser = localStorage.getItem("selectedUser");
  const [agingDatas, setAgingDatas] = useState([]);
  const [problematicDatas, setproblematicDatas] = useState([]);
  const [denialDatas, setDenialDatas] = useState([]);

  const [agingLoading, setAgingLoading] = useState(false);
  const [denialLoading, setDenialLoading] = useState(false);
  const [apiData, setApiData] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modelLoading, setModelLoading] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setAgingLoading(true);
      setDenialLoading(true);

      const [agingData, denialData, problematicDatas] = await Promise.all([
        getAgingAccountSummary(),
        getDenialAlertData(),
        getProblematicData()
      ]);

      if (agingData) setAgingDatas(agingData);
      if (denialData) setDenialDatas(denialData);
      if (problematicDatas) setDenialDatas(problematicDatas);

    } catch (error) {
      console.error("Dashboard data fetch failed:", error);
    } finally {
      setAgingLoading(false);
      setDenialLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    handleUserDropDown(true);
  }, []);

  useEffect(() => {
    const userChangeHandler = async () => {
      await fetchDashboardData();
    };

    window.addEventListener("reloadDashboardEvent", userChangeHandler);

    return () => {
      window.removeEventListener("reloadDashboardEvent", userChangeHandler);
    };
  }, []);

  const modifiedProblematicColumns = problematicAccount.columns.map((col) => {
    if (col.field === 'AIRecommendationAction') {
      return {
        ...col,
        body: (rowData) => (
          <button className="btn btn-success btn-sm" onClick={() => handleAddClick(rowData)}>
            Generate
          </button>
        )
      };
    }
    return col;
  });
  const handleAddClick = async (rowData) => {
    setModalVisible(true);
    setModelLoading(true);
    try {
      const response = await getGeneratedData(rowData.AccountNumber, rowData.BillNo, selectedUser);
      setApiData(response.data);
      setModelLoading(false);
    } catch (error) {
      console.error("API fetch error:", error);
    }
  };
  const modifiedAgingColumns = accountsReceivable.columns.map((col) => {
    if (col.field === 'Claims') {
      return {
        ...col,
        body: (rowData) => (
          <NavigationLink
            label={rowData.Claims}
            state={{ aging: rowData.Aging, url: 'aging/account' }}
            title="View aging account details"
          />
        )
      };
    }
    return col;
  });

  const modifiedDenialColumns = denials.columns.map((col) => {
    if (col.field === 'AccountCount') {
      return {
        ...col,
        body: (rowData) => (
          <NavigationLink
            label={rowData.AccountCount}
            state={{ DenialCode: rowData.DenialCodes, url: 'denial/alerts/details' }}
            title="View denial alert details"
          />
        )
      };
    }
    return col;
  });
  const renderCard = (title, content) => {
    if (!content) return null;
    return (
      <div className="card mb-3 border border-1 rounded">
        <div className="card-header fw-bold">{title}</div>
        <div className="card-body">
          <p className="card-text">{content}</p>
        </div>
      </div>
    );
  };
  return (
    <div className="main">
      <div className="content">
        <div className="container py-4">
          <h2 className="mb-4 fw-bold">Billing Navigator</h2>
          <div className="row">
            {/* Left Column */}
            <div className="col-md-7">
              <TableContainer title={problematicAccount.title}>
                <PrimeDataTable
                  columns={modifiedProblematicColumns}
                  data={problematicAccount.rows}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={insurerTracker.title}>
                <PrimeDataTable
                  columns={insurerTracker.columns}
                  data={insurerTracker.rows}
                  pagination={false}
                />
              </TableContainer>
            </div>

            {/* Right Column */}
            <div className="col-md-5">
              <TableContainer title={accountsReceivable.title}>
                <PrimeDataTable
                  columns={modifiedAgingColumns}
                  data={agingDatas}
                  loading={agingLoading}
                  pagination={false}
                />
              </TableContainer>
              <TableContainer title={denials.title}>
                <PrimeDataTable
                  columns={modifiedDenialColumns}
                  data={denialDatas}
                  loading={denialLoading}
                  pagination={false}
                />
              </TableContainer>
              {/* <TableContainer title={openClaims.title}>
                <PrimeDataTable
                  columns={openClaims.columns}
                  data={openClaims.rows}
                  pagination={false}
                />
              </TableContainer> */}
              <TableContainer title={paymentVariance.title}>
                <PrimeDataTable
                  columns={paymentVariance.columns}
                  data={paymentVariance.rows}
                  pagination={false}
                />
              </TableContainer>
            </div>

            { /* Model popuup for Problematic Accounts */}
            <Dialog header={<DialogHeader onClose={() => setShow(false)} accountNumber={apiData?.AccountNumber} />} visible={modalVisible} style={{ width: '65vw', background: '#372b59 !important' }} onHide={() => { if (!modalVisible) return; setModalVisible(false); setApiData(false); }}>
              {modelLoading ? (<ProgressSpinner style={{ "width": "100%", height: "50px" }} />) : <>
                {renderCard("Recommendation:", apiData?.recommendation)}
                {renderCard("Summary Of Billing", apiData?.billing_summary)}
                {renderCard("Interactions With Insurers", apiData?.insurer_interactions)}
                {renderCard("linked Bill Analysis", apiData?.linked_bill_analysis)}
              </>
              }
            </Dialog>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;