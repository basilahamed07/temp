/**
 * @file App.jsx
 * @summary Main application component for Blythedale Children's Hospital website
 * @description Root component that renders the complete hospital website with all sections and components
 * @author Sundar K
 * @since Jan 15, 2025
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from "./pages/Dashboard.jsx"
import ChatbotFloat from './components/common/ChatbotFloatButton.jsx';
import Sidebar from "./components/common/Sidebar.jsx";
import Topbar from "./components/common/Topbar.jsx";
import BillDetails from './pages/BillDetails.jsx';
import Bill from './pages/Bill.jsx';
import Accounts from './pages/Accounts.jsx';
import { useState } from 'react';
/**
 * Main application component that renders the complete hospital website
 *
 * @function App
 * @returns {JSX.Element} The complete application layout
 */
function App() {
  const [showUserDropDown, setShowUserDropDown] = useState(true);
  const handleUserDropDown = (flag) => {
    setShowUserDropDown(flag)
  }
  return (
    <BrowserRouter>
      <div>
        <Sidebar />
        <Topbar showUserDropDown={showUserDropDown}/>
        <div className='main-content-container'>
          <Routes>
            <Route path="/" element={<Dashboard handleUserDropDown={handleUserDropDown} />} />
            {/* <Route path="/tasks" element={<ActionableTaskSummary />} /> */}
            <Route path="/accounts" element={<Accounts handleUserDropDown={handleUserDropDown} />} />
            <Route path="/bill-details" element={<BillDetails handleUserDropDown={handleUserDropDown} />} />
            <Route path="/bills" element={<Bill handleUserDropDown={handleUserDropDown} />} />
            {/* Add more routes here as needed */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
      <ChatbotFloat />
    </BrowserRouter>
  )
}

export default App