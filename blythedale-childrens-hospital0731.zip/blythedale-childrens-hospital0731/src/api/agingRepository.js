import axios from "axios";
 
const getAgingAccountSummary = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/aging/${selectedUser}`;
        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching task summary by aging:', error);
        throw error;
    }
};
 
const getDenialAlertData = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }
        let API_URL =  `${import.meta.env.VITE_API_BASE_URL}/denial/alerts/${selectedUser}`;
        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching denial alert data:', error);
        throw error;
    }
};

const getProblematicData = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }
        let API_URL =  `${import.meta.env.VITE_API_BASE_URL}/top_5_problem/${selectedUser}`;
        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching denial alert data:', error);
        throw error;
    }
};
const getPaymentData = async () => {
    try {
        const selectedUser = localStorage.getItem("selectedUser");
        if (!selectedUser) {
            alert("Error: No user selected. Please select a user.");
            return;
        }
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/PaymentVariance/${selectedUser}`;
        const response = await axios.get(API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching denial alert data:', error);
        throw error;
    }
};

 
export { getAgingAccountSummary, getDenialAlertData, getProblematicData, getPaymentData };