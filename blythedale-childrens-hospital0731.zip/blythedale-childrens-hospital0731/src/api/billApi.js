import axios from "axios";

const getBillDetails = async (AccountNumber, BillNo) => {
    try {
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/bill/details/${AccountNumber}/${BillNo}`;
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching bill details:", error);
        throw error;
    }
};

const getBillBasedOnAccount = async (url) => {
    try {
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/${url}`;
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching bill details:", error);
        throw error;
    }
};
const getGeneratedData = async (AccountNumber, BillNo, EntryBy) => {
    try {
        if (import.meta.env.VITE_USE_JSON_DB) {
            let API_URL = `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/generatedData`; // Adjust this path if needed
            const response = await axios.get(API_URL);
            return response;
        }
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/action/${AccountNumber}${BillNo && `/${BillNo}`}`;
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching bill details:", error);
        throw error;
    }
}

export { getBillDetails, getBillBasedOnAccount, getGeneratedData };