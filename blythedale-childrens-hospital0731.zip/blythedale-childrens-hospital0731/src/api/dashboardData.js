const dashboardData = {
  problematicAccount: {
      title: "Top 5 Problematic Accounts",
      columns: [
        { field: "AccountNumber", header: "Account Number", sortable: false },
        { field: "DelayDurationDays", header: "Duration", sortable: false },
        { field: "TotalAmount", header: "Amount", sortable: false},
        { field: "AIRecommendationAction", header: "AI Recommendation   Action", sortable: false}
      ]
    },
    accountsReceivable: {
      title: "Aging Accounts Receivable Summary",
      columns: [
        { field: "Aging", header: "Aging", sortable: false, width: '10%' },
        { field: "Amount", header: "Amount ($)", sortable: false, width: '10%' },
        { field: "Claims", header: "Claims", sortable: false, width: '10%' },
        { field: "Priority", header: "Priority", sortable: false, width: '10%' }
      ]
    },
    denials: {
      title: "Denial Alerts & Resolution Tracker",
      columns: [
        { field: "DenialCodes", header: "Denial Code", sortable: false },
        { field: "Description", header: "Description", sortable: false },
        { field: "AccountCount", header: "Count", sortable: false },
      ]
    },
    insurerTracker: {
      title: "Insurer Issue Tracker",
      columns: [
        { field: "insurer", header: "Insurer", sortable: false },
        { field: "issue", header: "Recurring Issue", sortable: false },
        { field: "claims", header: "Count", sortable: false },
        { field: "recommendation", header: "Action Recommendation", sortable: false }
      ],
      rows: [
        {
          insurer: "MCD",
          issue: "Over-limit therapy denials",
          claims: 7,
          trend: "Rising",
          recommendation: "Submit frequency override request"
        },
        {
          insurer: "HFHSP",
          issue: "Missing authorization details",
          claims: 5,
          trend: "Rising",
          recommendation: "Match EMR and claim auth data"
        },
        {
          insurer: "Aetna",
          issue: "OT/ST claims missing modifiers",
          claims: 6,
          trend: "Stable",
          recommendation: "Re-train team on proper modifier usage"
        },
        {
          insurer: "EMPBCCON",
          issue: "Neuro PT marked as non-covered",
          claims: 4,
          trend: "Falling",
          recommendation: "Confirm coverage in benefits portal"
        },
        {
          insurer: "BENEXHAUST",
          issue: "NPI/taxonomy code mismatch",
          claims: 3,
          trend: "Rising",
          recommendation: "Correct taxonomy in claim profile"
        },
        {
          insurer: "MCD",
          issue: "Over-limit therapy denials",
          claims: 7,
          trend: "Rising",
          recommendation: "Submit frequency override request"
        },
        {
          insurer: "HFHSP",
          issue: "Missing authorization details",
          claims: 5,
          trend: "Rising",
          recommendation: "Match EMR and claim auth data"
        },
        {
          insurer: "Aetna",
          issue: "OT/ST claims missing modifiers",
          claims: 6,
          trend: "Stable",
          recommendation: "Re-train team on proper modifier usage"
        },
        {
          insurer: "EMPBCCON",
          issue: "Neuro PT marked as non-covered",
          claims: 4,
          trend: "Falling",
          recommendation: "Confirm coverage in benefits portal"
        },
        {
          insurer: "BENEXHAUST",
          issue: "NPI/taxonomy code mismatch",
          claims: 3,
          trend: "Rising",
          recommendation: "Correct taxonomy in claim profile"
        }
      ]
    },
    openClaims: {
      title: "Open Claims",
      columns: [
        { field: "accountNumber", header: "Account Number", sortable: false },
        { field: "documentNeeded", header: "Document Needed", sortable: false },
        { field: "assignedTo", header: "Assigned To", sortable: false },
        { field: "followUpDate", header: "Follow-up Date", sortable: false }
      ],
      rows: [
        {
          accountNumber: "V00000164385",
          documentNeeded: "Progress Notes (PT)",
          assignedTo: "Rehab Dept",
          followUpDate: "07/19/2025"
        },
        {
          accountNumber: "V00000162930",
          documentNeeded: "Pre-auth Form",
          assignedTo: "Front Desk",
          followUpDate: "07/20/2025"
        }
      ]
    },
    renewals: {
      title: "Upcoming Authorizations for Renewal",
      columns: [
        { field: "patientId", header: "Patient ID", sortable: false },
        { field: "name", header: "Name", sortable: false },
        { field: "service", header: "Service", sortable: false },
        { field: "expiryDate", header: "Expiry Date", sortable: false },
        { field: "status", header: "Status", sortable: false }
      ],
      rows: [
        {
          patientId: "EO-B2023103015438441",
          name: "Emily R.",
          service: "OT (Neuro)",
          expiryDate: "07/19/2025",
          status: "Not Initiated"
        },
        {
          patientId: "EO-B2023071514430872",
          name: "Noah M.",
          service: "Ortho",
          expiryDate: "07/20/2025",
          status: "Request in Draft"
        },
        {
          patientId: "EO-B2024071013000987",
          name: "Ava L.",
          service: "Occupational Therapy",
          expiryDate: "07/22/2025",
          status: "Awaiting documentation"
        }
      ]
    },
    paymentVariance: {
      title: "Payment Variance",
      columns: [
        { field: "AccountNumber", header: "Account Number", sortable: false },
        // { field: "DelayDurationDays", header: "Duration", sortable: false },
        { field: "ADJAmount", header: "ADJ Amount($)", sortable: false },
        { field: "PAYAmount", header: "PAY Amount($)", sortable: false },
        { field: "PSTAmount", header: "PST Amount($)", sortable: false },
        { field: "REVAmount", header: "REV Amount($)", sortable: false },
        { field: "TotalAmount", header: "Total Amount($)", sortable: false }
      ]
    }
  };
   
  export default dashboardData;