import axios from "axios";
 
export const getUsers = async () => {
    try {
        let API_URL = `${import.meta.env.VITE_API_BASE_URL}/users/unique`;
        const response = await axios.get(API_URL);
        return response;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    }
};