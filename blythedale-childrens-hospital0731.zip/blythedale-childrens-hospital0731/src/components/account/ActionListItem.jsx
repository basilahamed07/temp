import React from "react";
import { TbBulb } from "react-icons/tb";

const ActionListItem = ({ item, index }) => {
  return (
    <div className="mb-4" key={index}>
      <div className="d-flex align-items-start">
        <div className="me-2">
          <TbBulb size={32} />
        </div>
        <div>
          <strong>{item.itemHeader}</strong><br />
          <small>{item.itemBody}</small>
        </div>
      </div>
    </div>
  );
};

export default ActionListItem;
