import React from "react";
import "./DocumentsList.css";
const DocumentsList = () => {
  const docs = [
    { name: "Claim form", checked: true },
    { name: "Medical Records", checked: true },
    { name: "Incident/Accident Report", checked: false },
    { name: "Photo/Video Evidence", checked: false },
    { name: "Medical Bills", checked: true },
    { name: "Proof of Insurance", checked: false },
    { name: "Employer Report", checked: false },
  ];

  return (
    <div className="card shadow-sm">
      <div className="card-header bg-purple text-white rounded-top">
        Documents List (MCD)
      </div>
      <div className="card-body small">
        <div className="row">
          {docs.map((doc, idx) => (
            <div className="col-md-6 mb-2" key={idx}>
              <div className="form-check small">
                <input
                  className="form-check-input custom-checkbox"
                  type="checkbox"
                  id={`doc-${idx}`}
                />
                <label className="form-check-label" htmlFor={`doc-${idx}`}>
                  {doc.name}
                </label>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DocumentsList;
