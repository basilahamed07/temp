import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Skeleton } from 'primereact/skeleton';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import styles from '../../styles/PrimeDataTable.module.css';

const customPaginatorTemplate = {
    'RowsPerPageDropdown': (options) => {
        return (
            <span style={{ display: 'flex', alignItems: 'center', marginRight: 8 }}>
                <span style={{ marginRight: 4, color: '#6b7280', fontSize: '1rem' }}>Rows per page:</span>
                {options.element}
            </span>
        );
    },
    'CurrentPageReport': (options) => options.element,
    'PrevPageLink': (options) => options.element,
    'NextPageLink': (options) => options.element
};

const PrimeDataTable = ({ columns, data, loading, error, filter = {}, pagination = false, ...props }) => {
    // Fallbacks
    const safeData = Array.isArray(data) ? data : [];
    const safeColumns = Array.isArray(columns) ? columns : [];

    // Filter logic
    let filteredData = safeData;
    if (filter && Object.keys(filter).length > 0) {
        filteredData = safeData.filter(row =>
            Object.entries(filter).every(([field, value]) =>
                value === '' ||
                (row[field] && String(row[field]).toLowerCase() === String(value).toLowerCase())
            )
        );
    }

    // Skeleton placeholder rows
    const skeletonRows = Array(3).fill({});

    return (
        <div className={styles.dataTableWrapper}>
            <DataTable
                value={loading ? skeletonRows : filteredData}
                paginator={pagination !== false}
                paginatorPosition="bottom"
                rows={10}
                rowsPerPageOptions={[10, 15, 20]}
                paginatorTemplate={customPaginatorTemplate}
                currentPageReportTemplate="{first}-{last} of {totalRecords}"
                paginatorClassName={styles.customPaginator}
                paginatorDropdownAppendTo="self"
                showGridlines
                className={styles.dataTable}
                emptyMessage="No records available"
                {...props}
            >   
            
                {safeColumns.map(col => (
                    <Column
                        key={col.field}
                        field={col.field}
                        header={col.header}
                        sortable={col.sortable}
                        // headerStyle={{ textAlign: 'right' }}
                        bodyStyle={col.bodyStyle}
                        style={{
                            width: col.width || 'auto',
                            whiteSpace: 'normal',
                            wordWrap: 'break-word'
                        }}
                        body={
                            loading
                                ? () => <Skeleton width="100%" height="1.5rem" />
                                : col.body || undefined
                        }
                    />
                ))}
            </DataTable>
        </div>
    );
};

export default PrimeDataTable;
