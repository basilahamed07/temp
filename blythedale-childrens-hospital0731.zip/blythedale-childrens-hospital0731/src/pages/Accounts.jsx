/**
 * @file TaskList.jsx
 * @summary Actionable Task Summary component
 * @description This component displays the actionable task summary for the day
 * @author 
 * @since Jan 15, 2025
 */
import React, { useEffect, useState } from 'react'
import PrimeDataTable from '../components/common/PrimeDataTable';
import { fetchActionableTaskSummary } from '../api/taskRepository';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import TableContainer from '../components/common/TableContainer';
import { Dialog } from "primereact/dialog";
import DialogHeader from '../components/common/DialogHeader';
import { getGeneratedData } from '../api/billApi';
import { ProgressSpinner } from 'primereact/progressspinner';
/**
 * @function TaskList
 * @description This component displays the actionable task summary for the day
 * @returns {JSX.Element} The TaskList component
 */
function Account({handleUserDropDown}) {
    const selectedUser = localStorage.getItem("selectedUser");
    const [actionableTasks, setActionableTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const location = useLocation();
    const code = location.state?.DenialCode ? location.state?.DenialCode : location.state?.aging ? location.state?.aging : '';
    const url = location.state?.url;
    
  const [apiData, setApiData] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modelLoading, setModelLoading] = useState(false);
    /**
    * @function fetchData
    * @description This function fetches the actionable task summary for the day
    * @returns {Promise<void>} The Promise that resolves to the actionable task summary
    */
    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await fetchActionableTaskSummary(code, url);
            setActionableTasks(data);
        } catch (err) {
            setError('Failed to load actionable tasks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
        handleUserDropDown(false);
    }, []);
    // Define columns for the PrimeDataTable
    const columns = [
        { field: 'AccountNumber', header: 'Account ID', sortable: false},
        { field: 'BillCount', header: 'Bill Count', sortable: false, body: (rowData) => (
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                navigate('/bills', { state: { AccountNumber: rowData.AccountNumber , DenialCode: location.state?.DenialCode,aging: location.state?.aging, accounturl:location.state?.url ,  url: `${location.state?.DenialCode? "denial/account/details": "aging/details/bills"}/${rowData.AccountNumber}/${code}?entry_by=${selectedUser}`} });
                // navigate(`/accounts?test=asdfAccountNumber=${rowData.AccountNumber}&BillNo=${rowData.BillNo}`);
              }}
              style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer',  whiteSpace: 'normal', wordBreak: 'break-word' }}
            >
              {rowData.BillCount}
            </a>
          ) },
        { field: 'Name', header: 'Name', sortable: false },
        { field: 'AccountType', header: 'Account Type', sortable: false},
        { field: 'TotalAmount', header: 'Total Amount', sortable: false },
        { field: 'EntryBy', header: 'Biller', sortable: false },
        { field: 'Action', header: 'Action', sortable: false, body: (rowData) => (
            <button className="btn btn-success btn-sm" onClick={() => handleAddClick(rowData)}>
                Generate
            </button>
          ) }
    ];

    const handleAddClick = async (rowData) => {
        setModalVisible(true);
        setModelLoading(true);
        try {
            setTimeout(async() => {
                const response = await getGeneratedData(rowData.AccountNumber, rowData.BillNo, selectedUser);
                setApiData(response.data);
                setModelLoading(false);
              }, 5000);
        } catch (error) {
            console.error("API fetch error:", error);
        }
      };
      const renderCard = (title, content) => {
        if (!content) return null;
        return (
            <div className="card mb-3 border border-1 rounded">
                <div className="card-header fw-bold">{title}</div>
                <div className="card-body">
                    <p className="card-text">{content}</p>
                </div>
            </div>
        );
    };

    return (
        <div className='main'>
            <div className='content'>
                <div className="container py-4">
                    <h2 className="mb-4 fw-bold">{location.state?.DenialCode ? "Denial Alerts" :"Accounts"}</h2>
                    <TableContainer>
                        <PrimeDataTable columns={columns} data={actionableTasks} loading={loading} error={error} pagination={true} />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 32 }}>
                            <button
                                style={{
                                    background: '#7c3aed',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: 12,
                                    padding: '10px 36px',
                                    fontWeight: 600,
                                    fontSize: '1rem',
                                    boxShadow: '0 2px 8px rgba(124,58,237,0.10)',
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    outline: 'none',
                                }}
                                onClick={() => navigate('/')}
                            >
                                Back
                            </button>
                        </div>
                    </TableContainer>
                </div>
            </div>
            { /* Model popuup for Problematic Accounts */}
            <Dialog header={<DialogHeader onClose={() => setShow(false)} accountNumber={apiData?.AccountNumber} />} visible={modalVisible} style={{ width: '65vw', background: '#372b59 !important' }} onHide={() => { if (!modalVisible) return; setModalVisible(false); setApiData(false); }}>
                {modelLoading ? (<ProgressSpinner style={{ "width": "100%" , height:"50px"}} />) : <>
                    {renderCard("Recommendation:", apiData?.recommendation )}
                    {renderCard("Summary Of Billing", apiData?.billing_summary)}
                    {renderCard("Interactions With Insurers", apiData?.insurer_interactions)}
                    {renderCard("linked Bill Analysis", apiData?.linked_bill_analysis)}
                </>
                }
            </Dialog>
        </div>
    )
}

export default Account