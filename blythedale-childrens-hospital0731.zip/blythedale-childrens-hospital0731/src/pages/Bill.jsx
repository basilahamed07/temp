/**
 * @file TaskList.jsx
 * @summary Actionable Task Summary component
 * @description This component displays the actionable task summary for the day
 * @author 
 * @since Jan 15, 2025
 */
import React, { useEffect, useState } from 'react'
import PrimeDataTable from '../components/common/PrimeDataTable';
import { getBillBasedOnAccount } from '../api/billApi';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import TableContainer from '../components/common/TableContainer';
import { Dialog } from "primereact/dialog";
import DialogHeader from '../components/common/DialogHeader';
import { getGeneratedData } from '../api/billApi';
import { ProgressSpinner } from 'primereact/progressspinner';

/**
 * @function TaskList
 * @description This component displays the actionable task summary for the day
 * @returns {JSX.Element} The TaskList component
 */
function TaskList({ handleUserDropDown }) {
    const selectedUser = localStorage.getItem("selectedUser");
    const [actionableTasks, setActionableTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [modelLoading, setModelLoading] = useState(false);
    const [error, setError] = useState(null);
    const [modalVisible, setModalVisible] = useState(null);
    const [apiData, setApiData] = useState(null);
    const navigate = useNavigate();
    const location = useLocation();
    const code = location.state?.DenialCode ? location.state?.DenialCode : location.state?.aging ? location.state?.aging : '';
    const url = location.state?.url;

    /**
    * @function fetchData
    * @description This function fetches the actionable task summary for the day
    * @returns {Promise<void>} The Promise that resolves to the actionable task summary
    */
    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            const resposne = await getBillBasedOnAccount(url);
            setActionableTasks(resposne.data);
        } catch (err) {
            setError('Failed to load actionable tasks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };
    const handleAddClick = async (rowData) => {
        // setSelectedRow(rowData);
        setModalVisible(true);
        setModelLoading(true);
        try {
                const response = await getGeneratedData(rowData.AccountNumber, rowData.BillNo, selectedUser);
                setApiData(response.data);
                setModelLoading(false);
            // Sample API call using row ID

        } catch (error) {
            console.error("API fetch error:", error);
        }
    };
    useEffect(() => {
        fetchData();
        handleUserDropDown(false);
    }, []);
    // Define columns for the PrimeDataTable
    const columns = [
        { field: 'AccountNumber', header: 'Account ID', sortable: false },
        {
            field: 'BillNo', header: 'Bill No', sortable: false, body: (rowData) => (
                <a
                    href="#"
                    onClick={(e) => {
                        e.preventDefault();
                        navigate('/bill-details', { state: { AccountNumber: rowData.AccountNumber, BillNo: rowData.BillNo, billUrl: url, state: location.state.state } });
                        // navigate(`/accounts?test=asdfAccountNumber=${rowData.AccountNumber}&BillNo=${rowData.BillNo}`);
                    }}
                    style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer', whiteSpace: 'normal', wordBreak: 'break-word' }}
                >
                    {rowData.BillNo}
                </a>
            )
        },
        { field: 'AccountType', header: 'Account Type', sortable: false },
        { field: 'TotalAmount', header: 'Total Amount', sortable: false },
        { field: 'EntryBy', header: 'Biller', sortable: false },
        {
            field: 'Action Required', header: 'Action Required', sortable: false, body: (rowData) => (
                <button className="btn btn-success btn-sm" onClick={() => handleAddClick(rowData)}>
                    Generate
                </button>
            )
        }
    ];
    const renderCard = (title, content) => {
        if (!content) return null;
        return (
            <div className="card mb-3 border border-1 rounded">
                <div className="card-header fw-bold">{title}</div>
                <div className="card-body">
                    <p className="card-text">{content}</p>
                </div>
            </div>
        );
    };
    return (
        <div className='main'>

            <div className='content'>
                <div className="container py-4">
                    <h2 className="mb-4 fw-bold">Bills</h2>
                    <TableContainer>
                        <PrimeDataTable columns={columns} data={actionableTasks} loading={loading} error={error} pagination={true} />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 32 }}>
                            <button
                                style={{
                                    background: '#7c3aed',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: 12,
                                    padding: '10px 36px',
                                    fontWeight: 600,
                                    fontSize: '1rem',
                                    boxShadow: '0 2px 8px rgba(124,58,237,0.10)',
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    outline: 'none',
                                }}
                                onClick={() => (location?.state?.state == "dashbosrd")? navigate('/') : navigate('/accounts', { state: { DenialCode: location.state?.DenialCode, aging: location.state?.aging, url: location.state?.accounturl } })}
                            >
                                Back
                            </button>
                        </div>
                    </TableContainer>
                </div>
            </div>
            <Dialog header={<DialogHeader onClose={() => setShow(false)} billNumber={apiData?.BillNo} accountNumber={apiData?.AccountNumber} />} visible={modalVisible} style={{ width: '65vw', background: '#372b59 !important' }} onHide={() => { if (!modalVisible) return; setModalVisible(false); setApiData(false); }}>
                {/* {if (apiData && apiData.ModelSummary && apiData.ModelSummary.RecommendationForNextAction) {} */}
                {/* <div className=" border border-1 rounded mb-3 shadow-sm">
                    <div className="header p-3 pb-0 fw-bold">Recommendation For Next Action</div>
                    <div className="body p-3">{apiData?.ModelSummary?.RecommendationForNextAction}</div>
                </div>
                <div className="border border-1 rounded mb-3 shadow-sm">
                    <div className="header p-3 pb-0 fw-bold">InteractionsWithInsurers</div>
                    <div className="body p-3">{apiData?.ModelSummary?.InteractionsWithInsurers}</div>
                </div>
                <div className="border border-1 rounded mb-3 shadow-sm">
                    <div className="header p-3 pb-0 fw-bold">InteractionsWithInsurers</div>
                    <div className="body p-3">{apiData?.ModelSummary?.InteractionsWithInsurers}</div>
                </div> */}
                {modelLoading ? (<ProgressSpinner style={{ "width": "100%" , height:"50px"}} />) : <>
                    {renderCard("Recommendation For Next Action", apiData?.ModelSummary?.RecommendationForNextAction)}
                    {renderCard("Interactions With Insurers", apiData?.ModelSummary?.InteractionsWithInsurers)}
                    {renderCard("Summary Of Billing History", apiData?.ModelSummary?.SummaryOfBillingHistory)}
                </>
                }
            </Dialog>
        </div>
    )
}

export default TaskList

