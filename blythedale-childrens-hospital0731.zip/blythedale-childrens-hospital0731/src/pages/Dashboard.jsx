/**
 * @file Dashboard.jsx
 * @summary Dashboard component for Blythedale Children's Hospital
 * @description This component displays the dashboard for the Blythedale Children's Hospital
 * @since Jan 15, 2025
 */

import React, { useState, useEffect } from 'react';
import "./Dashboard.css";
import TableContainer from '../components/common/TableContainer';
import dashboardData from '../api/dashboardData';
import PrimeDataTable from '../components/common/PrimeDataTable';
import NavigationLink from "../components/common/NavigationLink";
import { getAgingAccountSummary, getDenialAlertData, getProblematicData, getPaymentData } from "../api/agingRepository";
import { Dialog } from "primereact/dialog";
import DialogHeader from '../components/common/DialogHeader';
import { getGeneratedData } from '../api/billApi';
import { ProgressSpinner } from 'primereact/progressspinner';
import { marked } from 'marked';
import { useNavigate } from 'react-router-dom';

function formatMarkdown(text) {
  try {
    if (typeof text !== 'string') return '';
    return marked.parse(text);
  } catch (err) {
    return typeof text === 'string' ? text.replace(/\n/g, '<br>') : '';
  }
}

function Dashboard({ handleUserDropDown }) {
  const {
    problematicAccount,
    accountsReceivable,
    denials,
    insurerTracker,
    openClaims,
    renewals,
    paymentVariance
  } = dashboardData;
  const selectedUser = localStorage.getItem("selectedUser");
  const [agingDatas, setAgingDatas] = useState([]);
  const [problematicDatas, setProblematicDatas] = useState([]);
  const [denialDatas, setDenialDatas] = useState([]);
  const [paymentDatas, setPaymentDatas] = useState([]);

  const [agingLoading, setAgingLoading] = useState(false);
  const [denialLoading, setDenialLoading] = useState(false);
  const [apiData, setApiData] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modelLoading, setModelLoading] = useState(false);
  const [problematicLoading, setProblematicLoading] = useState(false);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const navigate = useNavigate();

  const fetchDashboardData = async () => {
    try {
      setAgingLoading(true);
      setDenialLoading(true);
      setProblematicLoading(true);
      setPaymentLoading(true);

      const [agingData, denialData, problematicDatas, paymentDatas] = await Promise.all([
        getAgingAccountSummary(),
        getDenialAlertData(),
        getProblematicData(),
        getPaymentData()
      ]);

      if (agingData) setAgingDatas(agingData);
      if (denialData) setDenialDatas(denialData);
      if (problematicDatas) setProblematicDatas(problematicDatas);
      if (paymentDatas) setPaymentDatas(paymentDatas);
    } catch (error) {
      console.error("Dashboard data fetch failed:", error);
    } finally {
      setAgingLoading(false);
      setDenialLoading(false);
      setProblematicLoading(false);
      setPaymentLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    handleUserDropDown(true);
  }, []);

  useEffect(() => {
    const userChangeHandler = async () => {
      await fetchDashboardData();
    };

    window.addEventListener("reloadDashboardEvent", userChangeHandler);

    return () => {
      window.removeEventListener("reloadDashboardEvent", userChangeHandler);
    };
  }, []);
  const modifiedProblematicColumns = [
    {
      field: "AccountNumber", header: "Account Number", sortable: false, body: (rowData) => (
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            navigate('/bills', { state: { AccountNumber: rowData.AccountNumber, DenialCode: location.state?.DenialCode, aging: location.state?.aging, state: "dashbosrd", accounturl: location.state?.url, url: `PaymentVariance/Accounts/${rowData.AccountNumber}/${selectedUser}` } });
            // navigate(`/accounts?test=asdfAccountNumber=${rowData.AccountNumber}&BillNo=${rowData.BillNo}`);
          }}
          className="navigation-link"
        >
          {rowData.AccountNumber}
        </a>
      )
    },
    { field: "DelayDurationDays", header: "Duration", sortable: false },
    { field: "TotalAmount", header: "Amount", sortable: false, bodyStyle: { textAlign: 'Right' } },
    {
      field: "AIRecommendationAction", header: "AI Recommendation Action", sortable: false, bodyStyle: { textAlign: 'center' }, body: (rowData) => (
        <button className="btn btn-success btn-sm" onClick={() => handleAddClick(rowData)}>
          Generate
        </button>
      )
    }
  ];
  const paymentVarianceColumns = [
    {
      field: "AccountNumber", header: "Account Number", sortable: false, body: (rowData) => (
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            navigate('/bills', { state: { AccountNumber: rowData.AccountNumber, DenialCode: location.state?.DenialCode, aging: location.state?.aging, state: "dashbosrd", accounturl: location.state?.url, url: `PaymentVariance/Accounts/${rowData.AccountNumber}/${selectedUser}` } });
            // navigate(`/accounts?test=asdfAccountNumber=${rowData.AccountNumber}&BillNo=${rowData.BillNo}`);
          }}
          className="navigation-link"
        >
          {rowData.AccountNumber}
        </a>
      )
    },
    // { field: "DelayDurationDays", header: "Duration", sortable: false },
    { field: "ADJAmount", header: "ADJ Amount($)", sortable: false },
    { field: "PAYAmount", header: "PAY Amount($)", sortable: false },
    { field: "PSTAmount", header: "PST Amount($)", sortable: false },
    { field: "REVAmount", header: "REV Amount($)", sortable: false },
    { field: "TotalAmount", header: "Total Amount($)", sortable: false }
  ]



const handleAddClick = async (rowData) => {
  setModalVisible(true);
  setModelLoading(true);
  try {
    const response = await getGeneratedData(rowData.AccountNumber, rowData.BillNo, selectedUser);
    setApiData(response.data);
    setModelLoading(false);
  } catch (error) {
    console.error("API fetch error:", error);
  }
};
const modifiedAgingColumns = accountsReceivable.columns.map((col) => {
  if (col.field === 'Claims') {
    return {
      ...col,
      body: (rowData) => (
        <NavigationLink
          label={rowData.Claims}
          state={{ aging: rowData.Aging, url: 'aging/account' }}
          title="View aging account details"
        />
      )
    };
  }
  return col;
});

const modifiedDenialColumns = denials.columns.map((col) => {
  if (col.field === 'AccountCount') {
    return {
      ...col,
      body: (rowData) => (
        <NavigationLink
          label={rowData.AccountCount}
          state={{ DenialCode: rowData.DenialCodes, url: 'denial/alerts/details' }}
          title="View denial alert details"
        />
      )
    };
  }
  return col;
});
const renderCard = (title, content) => {
  if (!content) return null;
  return (
    <div className="card mb-3 border border-1 rounded">
      <div className="card-header fw-bold">{title}</div>
      <div className="card-body">
        {/* <p className="card-text">{content}</p> */}
        <span dangerouslySetInnerHTML={{ __html: formatMarkdown(content) }} />

      </div>
    </div>
  );
};
return (
  <div className="main">
    <div className="content">
      <div className="container py-4 row">
        <h2 className="mb-4 fw-bold">Billing Navigator</h2>
        <div className="row d-flex align-items-stretch">
          {/* Left Column */}
          <div className="col-md-7 d-flex flex-column" width="100%">
          <div className="h-100 d-flex flex-column justify-content-between">

            <TableContainer title={problematicAccount.title}>
              <PrimeDataTable
                columns={modifiedProblematicColumns}
                data={problematicDatas}
                loading={problematicLoading}
                pagination={false}
              />
            </TableContainer>
            <TableContainer title={insurerTracker.title}>
              <PrimeDataTable
                columns={insurerTracker.columns}
                data={insurerTracker.rows}
                pagination={false}
              />
            </TableContainer>
          </div>
          </div>

          {/* Right Column */}
          <div className="col-md-5 d-flex flex-column" height="100%">
          <div className="h-100 d-flex flex-column justify-content-between">

            <TableContainer title={accountsReceivable.title}>
              <PrimeDataTable
                columns={modifiedAgingColumns}
                data={agingDatas}
                loading={agingLoading}
                pagination={false} 
                scrollable
                scrollHeight="400px"
              />
            </TableContainer>
            <TableContainer title={denials.title}>
              <PrimeDataTable
                columns={modifiedDenialColumns}
                data={denialDatas}
                loading={denialLoading}
                pagination={false}                
                scrollable
                scrollHeight="250px"
              />
            </TableContainer>
            {/* <TableContainer title={openClaims.title}>
                <PrimeDataTable
                  columns={openClaims.columns}
                  data={openClaims.rows}
                  pagination={false}
                />
              </TableContainer> */}
            <TableContainer title={paymentVariance.title}>
              <PrimeDataTable
                columns={paymentVarianceColumns}
                data={paymentDatas}
                loading={paymentLoading}
                pagination={false}
              />
            </TableContainer>
          </div>
          </div>

          { /* Model popuup for Problematic Accounts */}
          <Dialog header={<DialogHeader onClose={() => setShow(false)} accountNumber={apiData?.AccountNumber} />} visible={modalVisible} style={{ width: '65vw', background: '#372b59 !important' }} onHide={() => { if (!modalVisible) return; setModalVisible(false); setApiData(false); }}>
            {modelLoading ? (<ProgressSpinner style={{ "width": "100%", height: "50px" }} />) : <>
              {renderCard("Recommendation:", apiData?.recommendation)}
              {renderCard("Summary Of Billing", apiData?.billing_summary)}
              {renderCard("Interactions With Insurers", apiData?.insurer_interactions)}
              {renderCard("linked Bill Analysis", apiData?.linked_bill_analysis)}
            </>
            }
          </Dialog>
        </div>
      </div>
    </div>
  </div>
);
}

export default Dashboard;
