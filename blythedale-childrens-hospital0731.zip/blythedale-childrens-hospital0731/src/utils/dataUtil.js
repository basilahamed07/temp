export function formatDate(input) {
    if (!input) return false;
  
    const date = new Date(input);
    if (isNaN(date)) return false;
  
    const day = date.getDate().toString().padStart(2, '0');
    const suffix = getDaySuffix(date.getDate());
    const month = date.toLocaleString('default', { month: 'long' });
    const year = date.getFullYear();
  
    return `${day}${suffix} ${month}, ${year}`;
  }
  
  function getDaySuffix(day) {
    if (day > 3 && day < 21) return 'th';
    switch (day % 10) {
      case 1: return 'st';
      case 2: return 'nd';
      case 3: return 'rd';
      default: return 'th';
    }
  }
  