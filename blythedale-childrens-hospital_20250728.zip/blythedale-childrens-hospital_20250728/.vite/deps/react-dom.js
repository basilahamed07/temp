import {
  require_react_dom
} from "./chunk-U5G3TOY2.js";
import "./chunk-6GAV2S6I.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
