import axios from "axios";

const fetchActionableTaskSummary = async (param, path) => {
  try {
    const selectedUser = localStorage.getItem("selectedUser");
    if (!selectedUser) {
      alert("Error: No user selected. Please select a user.");
      return;
    }
    let API_URL = `${import.meta.env.VITE_API_BASE_URL}/${path}/${selectedUser}/${param}`;

    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching task summary by aging:', error);
    throw error;
  }
};

export { fetchActionableTaskSummary };
