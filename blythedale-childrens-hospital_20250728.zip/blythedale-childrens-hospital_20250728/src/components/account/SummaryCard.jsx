import axios from "axios";
import React, { useEffect, useState } from "react";
import NotApplicable from "../common/NotApplicable";
import { formatDate } from "../../utils/dataUtil";
import { getBillDetails } from "../../api/billApi";

const SummaryCard = ({billDetails}) => {
    return (
        <div className="card h-100 shadow-sm">
            <div className="card-body">
                <h5 className="card-title">Summary</h5>

                <table className="table table-sm table-borderless">
                    <thead>
                        <tr>
                            <th>Field</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>Claim ID</th>
                            <td>{billDetails?.BillNo || <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Policyholder</th>
                            <td>{billDetails?.Name || <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Insurer</th>
                            <td>{billDetails?.CurrentPrimaryInsurance || <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Policy No</th>
                            <td>{billDetails?.PolicyNumber || <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Claim Amount</th>
                            <td>
                                {billDetails?.ClaimAmount != null
                                    ? `$${billDetails.ClaimAmount.toLocaleString()}`
                                    : <NotApplicable />}
                            </td>
                        </tr>
                        <tr>
                            <th>Contact</th>
                            <td>{billDetails?.Contact || <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>
                                {billDetails?.emailTo ? (
                                    <a href={`mailto:${billDetails.emailTo}`}>{billDetails.emailTo}</a>
                                ) : (
                                    <NotApplicable />
                                )}
                            </td>
                        </tr>
                        <tr>
                            <th>Claim Filed Date</th>
                            <td>{billDetails?.ClaimFiledDate ? formatDate(billDetails.ClaimFiledDate) : <NotApplicable />}</td>
                        </tr>
                        <tr>
                            <th>Expected Settlement</th>
                            <td>{billDetails?.ExpectedSettlement ? formatDate(billDetails.ExpectedSettlement) : <NotApplicable />}</td>
                        </tr>
                    </tbody>
                </table>


                <div className="d-flex justify-content-between align-items-center mb-2">
                    <div className="fw-bold">Progress Bar</div>
                    <span className="text-danger text-end small-text">Awaiting Investigation Report</span>
                </div>

                <div className="progress mb-1">
                    <div className="progress-bar progress-bar-custom" style={{ width: "16.67%" }}>
                        16.67%
                    </div>
                </div>
                <span className="text-danger small-text">
                    Claim pending document submission for more than 3 days
                </span>

                <div className="mt-3 d-flex justify-content-between align-items-center">
                    <div className="sub-process-step sub-process-active"></div>
                    <div className="sub-process-step"></div>
                    <div className="sub-process-step"></div>
                    <div className="sub-process-step"></div>
                </div>
                <div className="d-flex justify-content-between small mt-2">
                    <div>Initiated</div>
                    <div>Docs Submitted</div>
                    <div>Medical Eval</div>
                    <div>Approval</div>
                </div>
            </div>
        </div>
    );
};

export default SummaryCard;
